
IF EXISTS  (SELECT * FROM sys.objects 
  WHERE object_id = OBJECT_ID(N'uspCheckOverlapBeforeAdd') )
  DROP PROCEDURE uspCheckOverlapBeforeAdd;

GO

IF EXISTS (SELECT * FROM sys.objects 
     WHERE object_id = OBJECT_ID(N'uspCheckOverlapBeforeUpdate') )
  DROP PROCEDURE uspCheckOverlapBeforeUpdate;

GO 

CREATE PROCEDURE uspCheckOverlapBeforeAdd @customerId int,@StartDate date, @EndDate date
AS(
  SELECT * FROM AccountRate WHERE 
    ((@StartDate >= EffectiveStartDate and @StartDate <= EffectiveEndDate)
    OR (@EndDate >= EffectiveStartDate and @EndDate <= EffectiveEndDate)
    OR (@StartDate <= EffectiveStartDate and @EndDate >=EffectiveEndDate)) AND
	AccountRate.CustomerAccountId = @customerId 
)

GO

CREATE PROCEDURE uspCheckOverlapBeforeUpdate @RecordId int, @CustomerId int,@StartDate date, @EndDate date
AS(
  SELECT * FROM AccountRate WHERE 
    ((@StartDate >= EffectiveStartDate and @StartDate <= EffectiveEndDate)
    OR (@EndDate >= EffectiveStartDate and @EndDate <= EffectiveEndDate)
    OR (@StartDate <= EffectiveStartDate and @EndDate >=EffectiveEndDate)) AND
	AccountRate.CustomerAccountId = @CustomerId AND AccountRate.AccountRateId != @RecordId 
)
