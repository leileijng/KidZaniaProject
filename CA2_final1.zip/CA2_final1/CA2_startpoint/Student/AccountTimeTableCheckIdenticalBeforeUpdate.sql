use TMSDB_1844638
IF EXISTS  (SELECT * FROM sys.objects 
  WHERE object_id = OBJECT_ID(N'uspAccountTimeTableCheckIdenticalBeforeUpdate') )
  DROP PROCEDURE uspAccountTimeTableCheckIdenticalBeforeUpdate;

GO

CREATE PROCEDURE uspAccountTimeTableCheckIdenticalBeforeUpdate @timetableId int, @rateId int, @day int, @startDate date, @endDate date, @startTime int, @endTime int
AS(
  SELECT * FROM AccountTimeTable WHERE 
    (AccountTimeTable.AccountRateId = @rateId) AND
	(AccountTimeTable.DayOfWeekNumber = @day) AND
	(AccountTimeTable.EffectiveStartDate = @startDate) AND
	(AccountTimeTable.EffectiveEndDate = @endDate) AND
	(AccountTimeTable.StartTimeInMinutes = @startTime) AND
	(AccountTimeTable.EndTimeInMinutes = @endTime)
	AND
	AccountTimeTable.AccountTimeTableId != @timetableId
)

