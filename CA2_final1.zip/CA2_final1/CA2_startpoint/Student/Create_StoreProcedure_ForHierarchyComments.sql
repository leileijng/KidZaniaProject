use tmsdb_1844638

--If the database has the stored procedure, drop it. 
IF EXISTS (SELECT * FROM sys.objects                       
WHERE object_id = OBJECT_ID(N'uspGetCommentsHierarchy') )   
DROP PROCEDURE uspGetCommentsHierarchy;
GO 

 
--Declare uspGetCommentsHierarchy stored procedure 
CREATE PROCEDURE uspGetCommentsHierarchy @customerId int
AS  WITH  q  AS         
(         
SELECT  customerAccountCommentId, CustomerAccountId, Comment , ParentId        
FROM    CustomerAccountComment         
UNION ALL         
SELECT  p.customerAccountCommentId, p.CustomerAccountId, p.Comment, p.ParentId          
FROM    q         
JOIN    CustomerAccountComment p         
ON      p.customerAccountCommentId = q.ParentId          
),  
GroupedData  AS (    
SELECT customerAccountCommentId, COUNT(*)-1 AS NumOfSubordinates
FROM    q    
GROUP BY    
customerAccountCommentId ) 
 
   SELECT          
   CustomerAccountComment.customerAccountCommentId, customerAccountComment.CustomerAccountId, 
   CASE gd.NumOfSubordinates        
   WHEN 0 THEN CustomerAccountComment.Comment ELSE CONCAT('(', 
   gd.NumOfSubordinates, ' Reply) ',  AppUser.FullName, char(10), convert(varchar, CustomerAccountComment.CreatedAt, 3) , char(10), ': ', CustomerAccountComment.Comment) END AS Comment,    
   CustomerAccountComment.ParentId        FROM GroupedData gd    
   INNER JOIN CustomerAccountComment ON gd.customerAccountCommentId = CustomerAccountComment.customerAccountCommentId 
   Inner Join appuser on CustomerAccountComment.CreatedById = AppUser.Id
   where CustomerAccountComment.CustomerAccountId = @customerId
   GO 