/*********************************************************************/
-- The code which is required to create AppNote, AppNotePriorityLevel table, test records
-- and one stored procedure which supports record paging functionality
/*********************************************************************/
use TMSDB_1844638

IF OBJECT_ID('dbo.uspSelectNotes') IS NOT NULL
DROP PROCEDURE dbo.uspSelectNotes;
GO
  IF OBJECT_ID('dbo.AppNote') IS NOT NULL
DROP TABLE  dbo.AppNote;
GO
  IF OBJECT_ID('dbo.AppNotePriorityLevel') IS NOT NULL
DROP TABLE  dbo.AppNotePriorityLevel;
GO
  CREATE TABLE AppNotePriorityLevel(
	[AppNotePriorityLevelId] INT PRIMARY KEY IDENTITY(1,1) NOT NULL,
	[PriorityLevelName] VARCHAR(50) NOT NULL
 )
 CREATE TABLE AppNote(
	[AppNoteId] INT PRIMARY KEY IDENTITY(1,1) NOT NULL,
	[Note] VARCHAR(800) NOT NULL,
	[DoneAt] DATETIME2(7) NULL DEFAULT NULL,
	[DeadLine] DATETIME2(7) NOT NULL,
	[AppNotePriorityLevelId] INT NOT NULL REFERENCES AppNotePriorityLevel(AppNotePriorityLevelId),
	[CreatedAt] DATETIME2(7)   NOT NULL,
	[CreatedById] INT NOT NULL REFERENCES AppUser(id)
	
 )

SET IDENTITY_INSERT dbo.AppNotePriorityLevel ON 
GO
INSERT [dbo].AppNotePriorityLevel ([AppNotePriorityLevelId], [PriorityLevelName]) VALUES (1, N'DO IT EVEN IF NO TIME')
GO
INSERT [dbo].AppNotePriorityLevel ([AppNotePriorityLevelId], [PriorityLevelName]) VALUES (2, N'PLAN WHEN TO DO IT')
GO
INSERT [dbo].AppNotePriorityLevel ([AppNotePriorityLevelId], [PriorityLevelName]) VALUES (3, N'ASK SOMEONE ELSE TO DO IT')
GO
INSERT [dbo].AppNotePriorityLevel ([AppNotePriorityLevelId], [PriorityLevelName]) VALUES (4, N'DO IT WHEN GOT TIME')
GO
SET IDENTITY_INSERT dbo.AppNotePriorityLevel OFF
GO

 SET IDENTITY_INSERT dbo.AppNote ON 
GO
INSERT [dbo].AppNote (AppNoteId, Note, AppNotePriorityLevelId, DoneAt, DeadLine,CreatedAt,CreatedById) VALUES (3, 'Remember to prepare timetable for Emma''s Toy Corner by October 30 or else Larry and Nancy will start screaming at me.' , 1, NULL, CAST(N'2019-10-30 00:00:00' AS DateTime2), CAST(N'2019-10-05 20:39:12.6535681' AS DateTime2), 1)
GO
INSERT [dbo].AppNote (AppNoteId, Note, AppNotePriorityLevelId, DoneAt, DeadLine,CreatedAt,CreatedById) VALUES (11, 'Update the current account rate for Riz Tech by extending the effective end date to 31/12/2019. Remember to make changes to the respective timetable effective end date too.' , 1,  NULL, CAST(N'2019-10-15 00:00:00' AS DateTime2), CAST(N'2019-10-06 20:39:12.6535681' AS DateTime2), 1)
GO
INSERT [dbo].AppNote (AppNoteId, Note, AppNotePriorityLevelId, DoneAt, DeadLine,CreatedAt,CreatedById) VALUES (21, 'Assign YAMAMOTO and SUSAN RICE to Gem Kid SchoolHouse due extra students before they generate timesheet in November 2019.' , 1, CAST(N'2019-10-23 16:40:00' AS DateTime2), CAST(N'2019-10-26 00:00:00' AS DateTime2), CAST(N'2019-10-06 21:39:12.6535681' AS DateTime2), 1)
GO
INSERT [dbo].AppNote (AppNoteId, Note, AppNotePriorityLevelId, DoneAt, DeadLine,CreatedAt,CreatedById) VALUES (22, 'Account rate effective period going to end soon for Starline Tech company (October 2019). Need to check with Sales department before Roger creates timesheet for November 2019' , 2, CAST(N'2019-10-15 11:13:00' AS DateTime2), CAST(N'2019-10-19 00:00:00' AS DateTime2), CAST(N'2019-10-06 21:45:12.6535681' AS DateTime2), 1)
GO
INSERT [dbo].AppNote (AppNoteId, Note, AppNotePriorityLevelId, DoneAt, DeadLine,CreatedAt,CreatedById) VALUES (25, 'KENNY going for holiday break for one week in December 2019. Need to find another instructor to temporary replace Kenny for one month' , 2, NULL, CAST(N'2019-10-30 00:00:00' AS DateTime2), CAST(N'2019-10-07 09:10:12.6535681' AS DateTime2), 1)
GO
INSERT [dbo].AppNote (AppNoteId, Note, AppNotePriorityLevelId, DoneAt, DeadLine,CreatedAt,CreatedById) VALUES (31, 'Gem Kid SchoolHouse has asked to cancel Friday timetable for two weeks in December 2019, need to check with them which week they are referring to. ' , 2, CAST(N'2019-10-13 11:20:00' AS DateTime2), CAST(N'2019-10-15 00:00:00' AS DateTime2), CAST(N'2019-10-07 09:39:12.6535681' AS DateTime2), 1)
GO
INSERT [dbo].AppNote (AppNoteId, Note, AppNotePriorityLevelId, DoneAt, DeadLine,CreatedAt,CreatedById) VALUES (33, 'LORI has to go overseas in January 2020. Need to check with LARRY, JANET if they are interested to give training in Emma''s Toy Corner starting from January 2020' , 3, NULL , CAST(N'2019-10-30 00:00:00' AS DateTime2), CAST(N'2019-10-07 20:39:12.6535681' AS DateTime2), 1)
GO
INSERT [dbo].AppNote (AppNoteId, Note, AppNotePriorityLevelId, DoneAt, DeadLine,CreatedAt,CreatedById) VALUES (50, 'Need to check Robert''s timesheet in mid month. He is a new free lance instructor and first time using the application to manage timesheet' , 4, NULL, CAST(N'2020-10-15 00:00:00' AS DateTime2), CAST(N'2019-10-15 00:00:00' AS DateTime2), 1)
GO
INSERT [dbo].AppNote (AppNoteId, Note, AppNotePriorityLevelId, DoneAt, DeadLine,CreatedAt,CreatedById) VALUES (51, 'Katty highlighted to me that travelling distance is "too long" (1 hour) between GreenTech Pte Ltd training venue and SouthStar Pte Ltd training venue. Need to discuss with customer to re-arrange timetable.' , 1, NULL, CAST(N'2019-10-16 00:00:00' AS DateTime2), CAST(N'2019-10-07 21:45:00' AS DateTime2), 1)
GO
INSERT [dbo].AppNote (AppNoteId, Note, AppNotePriorityLevelId, DoneAt, DeadLine,CreatedAt,CreatedById) VALUES (55, 'Remind all instructor to try submit timesheet by 26/10/2019. There is a public holiday DEEPAVALI on 27 Oct 2019' , 1, NULL, CAST(N'2019-10-21 00:00:00' AS DateTime2), CAST(N'2019-10-08 09:20:15' AS DateTime2), 1)
GO
INSERT [dbo].AppNote (AppNoteId, Note, AppNotePriorityLevelId, DoneAt, DeadLine,CreatedAt,CreatedById) VALUES (67, 'Gem Kid SchoolHouse want to "last minute" change timetable monday to 11AM-01PM. Need to check with Nancy if she is okay with that.' , 1, CAST(N'2019-10-11 10:15:00' AS DateTime2), CAST(N'2019-10-11 00:00:00' AS DateTime2), CAST(N'2019-10-08 09:41:00' AS DateTime2), 1)
GO
INSERT [dbo].AppNote (AppNoteId, Note, AppNotePriorityLevelId, DoneAt, DeadLine,CreatedAt,CreatedById) VALUES (69, 'Jacky Chan wants dancing lessons from Monday to Friday each day for one week ONLY in December 2019. Check with boss who are the likely instructors we need to assign.' , 2, CAST(N'2019-10-11 13:25:00' AS DateTime2), CAST(N'2019-10-13 00:00:00' AS DateTime2), CAST(N'2019-10-08 13:30:00' AS DateTime2), 1)
GO
INSERT [dbo].AppNote (AppNoteId, Note, AppNotePriorityLevelId, DoneAt, DeadLine,CreatedAt,CreatedById) VALUES (72, 'Remind all instructors assigned to JCE Movies Limited (Jacky Chan company)  that they need manually create custom timesheet schedule for December 2019 because the timetable is too complicated to set in system.' , 2, NULL, CAST(N'2019-11-15 00:00:00' AS DateTime2), CAST(N'2019-10-09 22:15:00.6535681' AS DateTime2), 1)
GO
SET IDENTITY_INSERT dbo.AppNote OFF
GO

CREATE PROCEDURE uspSelectNotes
(
    /* Optional Filters for Dynamic Search*/
	/* The following one parameter is optional and the practical example do not use them*/
	/* It the parameters still remain here to assist those learners who 
	     wish to try out search feature (search by partial note text etc.) for user to use*/
  @note NVARCHAR(200) = NULL,

  /* This parameter is compulsory because the user can only view his own note records */
  @userId INT,
  /*The following four parameter variables are often fixed for any stored procedure 
      which supports record paging */
  /*� Pagination Parameters */
  /*-- If no argument is provided for @pageNo (e.g. @pageNo=1 is missing), the default value is 1 */
  @pageNo INT = 1,   
  @pageSize INT = 10,
   /*� Sorting Parameters */
   /*-- If no argument is provided for @sortColumn parameter
          For example, @sortColumn='DONEAT' is missing, the default value is 'DEADLINE' */
   @sortColumn NVARCHAR(20) = 'DEADLINE',
   @sortOrder NVARCHAR(4)='ASC'
)
AS
BEGIN
    /*�Declaring local Variables corresponding to parameters for modification */
    DECLARE 
    @_note NVARCHAR(100),
	@_userId INT,
    /*�The following 6 local variables are used as part of the SQL logic to support
	      fetching the correct records fitting into the specified page number.
		  These variables are fixed for all stored procedures which support record paging. */
    @_pageNbr INT,
    @_pageSize INT,
    @_sortCol NVARCHAR(20),
    @_firstRec INT,
    @_lastRec INT,
    @_totalRows INT

    /*Setting local Variables*/
	/*Copying all parameter input values into the respective local variables */
    SET @_note = LTRIM(RTRIM(@note))
	SET @_userId = @userId
	/*The following 6 commands rarely changed unless I encounter new inspiration
	   shared by good developers' articles and video */
	/*These 6 commands are used to calculate the correct set of records that can fit
	    into the specified page number (e.g. page 1, page 2 etc). 
		Without the correct value for the @_firstRec and @lastRec, the SQL logic will fail to retrieve
		the correct set of records */
    SET @_pageNbr = @pageNo
    SET @_pageSize = @pageSize
    SET @_sortCol = LTRIM(RTRIM(@sortColumn))

    SET @_firstRec = ( @_pageNbr - 1 ) * @_pageSize
    SET @_lastRec = ( @_pageNbr * @_pageSize + 1 )
    SET @_totalRows = @_firstRec - @_lastRec + 1

    ; WITH CTE_Results
    AS (
    SELECT ROW_NUMBER() OVER (ORDER BY

	/* These are just partial code to decide sort by which column and sequence */
	/* Notice I did not provide all. For example, I have skipped coding sort logic for AppNotePriorityLevelId */
        CASE WHEN (@_sortCol = 'NOTE' AND @sortOrder='ASC')
                    THEN Note
        END ASC,
        CASE WHEN (@_sortCol = 'NOTE' AND @sortOrder='DESC')
                  THEN Note
        END DESC,

        CASE WHEN (@_sortCol = 'DONEAT' AND @sortOrder='ASC')
                  THEN DoneAt
        END ASC,
        CASE WHEN @_sortCol = 'DONEAT' AND @sortOrder='DESC'
                THEN DoneAt
        END DESC,

        CASE WHEN (@_sortCol = 'DEADLINE' AND @sortOrder='ASC')
                  THEN Deadline
        END ASC,
        CASE WHEN @_sortCol = 'DEADLINE' AND @sortOrder='DESC'
                THEN Deadline
        END DESC


  ) AS ROWNUM,
  Count(*) over () AS TotalCount,
  AppNoteId,
  Note,
  DoneAt,
  DeadLine
 FROM AppNote
 WHERE
    (@_note IS NULL OR Note LIKE '%' + @_note + '%')
    AND (CreatedById = @userId)
)
SELECT
  TotalCount,
  ROWNUM,
  AppNoteId,
  Note,
  DoneAt,
  DeadLine
FROM CTE_Results AS CPC
WHERE
        ROWNUM > @_firstRec
         AND ROWNUM < @_lastRec
 ORDER BY ROWNUM ASC

END
GO
/*********************************************************************/
-- END
-- The code which is required to create AppNote, AppNotePriorityLevel table, test records
-- and one stored procedure which supports record paging functionality
/*********************************************************************/
