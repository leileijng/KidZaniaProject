use TMSDB_1844638
IF EXISTS  (SELECT * FROM sys.objects 
  WHERE object_id = OBJECT_ID(N'uspTimeTableCheckOverlapBeforeUpdate') )
  DROP PROCEDURE uspTimeTableCheckOverlapBeforeUpdate;

GO

CREATE PROCEDURE uspTimeTableCheckOverlapBeforeUpdate @timetableId int, @rateId int, @day int, @startDate date, @endDate date, @startTime int, @endTime int
AS(
  SELECT * FROM AccountTimeTable WHERE 
  (AccountTimeTable.AccountRateId = @rateId) AND
	(AccountTimeTable.DayOfWeekNumber = @day) AND
	((@startDate >= AccountTimeTable.EffectiveStartDate and @startDate <= AccountTimeTable.EffectiveEndDate)
    OR (@endDate >= AccountTimeTable.EffectiveStartDate and @endDate <= AccountTimeTable.EffectiveEndDate)
    OR (@startDate <= AccountTimeTable.EffectiveStartDate and @endDate >=AccountTimeTable.EffectiveEndDate)) 
	AND
    ((@startTime >= AccountTimeTable.StartTimeInMinutes and @startTime <= AccountTimeTable.EndTimeInMinutes)
    OR (@endTime >= AccountTimeTable.StartTimeInMinutes and @endTime <= AccountTimeTable.EndTimeInMinutes)
    OR (@startTime <= AccountTimeTable.StartTimeInMinutes and @endTime >=AccountTimeTable.EndTimeInMinutes)) 
	AND @timetableId != AccountTimeTable.AccountTimeTableId
)

