﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TMS.Controllers
{
    public class AppNotesController : Controller
    {
        // GET: /<controller>/
        public IActionResult Index()
        {
            return View();
        }//End of Index action method

        public IActionResult CreateOneNote()
        {
            return View();
        }//End of CreateOneNote action method
    }//End f action controller class
}//End of namespace
