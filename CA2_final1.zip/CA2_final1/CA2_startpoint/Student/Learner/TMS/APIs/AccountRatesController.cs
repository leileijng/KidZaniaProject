﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.EntityFrameworkCore;
using TMS.Data;
using TMS.Models;
using TMS.Services;
using FluentValidation;
using FluentValidation.Results;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TMS.APIs
{
    [Route("api/[controller]")]
    public class AccountRatesController : Controller
    {        
        //The following one member variable and one readonly property          
        //are required for every web api controller class. 
        private IAppDateTimeService _appDateTimeService;
        public ApplicationDbContext Database { get; } //Read-only Database property has been declared so that we can reference the given database object

        //The following constructor code pattern is required for every Web API     
        //controller class. 
        public AccountRatesController(IAppDateTimeService appDateTimeService,
            ApplicationDbContext database)
        {

            Database = database;
            _appDateTimeService = appDateTimeService;
        } //End of the constructor



        [Authorize("ADMIN")]
        [HttpGet("RatesByCustomer/{customerId}")]
        public IActionResult GetRatesByCustomerAccount(int customerId)
        {
            List<AccountRate> accountRateListQueryResults = new List<AccountRate>();
            accountRateListQueryResults = Database.AccountRates.Include(z => z.CreatedBy).Where(y => y.CustomerAccountId == customerId).ToList();
               
            if(accountRateListQueryResults == null)
            {
                return NotFound(new { message = "Cannot find any rate for this customer." });
            }

            List<object> accountRatesList = new List<object>();

            foreach (var oneAccountRate in accountRateListQueryResults)
            {
                accountRatesList.Add(new
                {
                    rateId = oneAccountRate.AccountRateId,
                    rate = oneAccountRate.RatePerHour,
                    start = Convert.ToDateTime(oneAccountRate.EffectiveStartDate).ToString("dd/MM/yyyy"),
                    end = Convert.ToDateTime(oneAccountRate.EffectiveEndDate).ToString("dd/MM/yyyy"),
                });
            }
            return Ok(accountRatesList);
        }



        [Authorize("ADMIN")]
        [HttpGet("{rateId}")]
        public IActionResult GetOneRate(int rateId)
        {
            AccountRate foundOneRate = Database.AccountRates.Include(x=>x.CustomerAccount).SingleOrDefault(y => y.AccountRateId == rateId);

            if(foundOneRate != null)
            {
                var response = new
                {
                    customerAccount = foundOneRate.CustomerAccount.AccountName,
                    rate = foundOneRate.RatePerHour,
                    start = Convert.ToDateTime(foundOneRate.EffectiveStartDate).ToString("dd/MM/yyyy"),
                    end = Convert.ToDateTime(foundOneRate.EffectiveEndDate).ToString("dd/MM/yyyy"),

                };
                return Ok(response);
            }
            else
            {
                return NotFound(new { message = "Cannot find this rate record. Please refresh the page!" });
            }
            
        }




        [Authorize("ADMIN")]
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            string customMessage = "";

            AccountRate foundOneRate = Database.AccountRates.SingleOrDefault(y => y.AccountRateId == id);
            //Call the remove method, pass the foundOneStudent object into it
            //so that the Database object knows what to remove from the database.
            if (foundOneRate == null)
            {
                return NotFound(new { message = "Cannot find" });
            }

            try
            {
                Database.AccountRates.Remove(foundOneRate);
                //Tell the db model to commit/persist the changes to the database, 
                //I use the following command.
                Database.SaveChanges();
            }
            catch (Exception ex)
            {
                customMessage = "Unable to delete rate record because " + ex.InnerException.Message + ".";
                return BadRequest(new { message = customMessage });
            }//End of try .. catch block on manage data

            return Ok(new { message = "Deleted account rate record successfully!" });
        }




        [Authorize("ADMIN")]
        [HttpPost]
        public IActionResult Post([FromForm] IFormCollection data)
        {
            int userId = int.Parse(User.FindFirst("userid").Value);
            string customMessage = "";
            string error = "";
            if(validateDataType(data["rate"], data["start"], data["end"]) != null)
            {
                return validateDataType(data["rate"], data["start"], data["end"]);
            }
            else
            {
                //Create an object AccountRate type object
                AccountRate newAccountRate = new AccountRate();
                
                //Start passing the collected data into the new AccountRate object
                newAccountRate.CustomerAccountId = int.Parse(data["customerAccountId"]);
                newAccountRate.RatePerHour = decimal.Parse(data["rate"]);
                newAccountRate.EffectiveStartDate = DateTime.ParseExact(data["start"], "dd/MM/yyyy", CultureInfo.InvariantCulture);
                newAccountRate.EffectiveEndDate = DateTime.ParseExact(data["end"], "dd/MM/yyyy", CultureInfo.InvariantCulture);
                newAccountRate.CreatedById = userId;
                newAccountRate.UpdatedAt = _appDateTimeService.GetCurrentDateTime();
                newAccountRate.CreatedAt = _appDateTimeService.GetCurrentDateTime();
                newAccountRate.UpdatedById = userId;

                //using fluentValidation to check each property 
                if (validateProperty(newAccountRate) != null)
                {
                    return validateProperty(newAccountRate);
                }

                //validating the overlap using stored procedure
                var overlappingRates =
                    Database
                    .AccountRates
                    .FromSql($"uspCheckOverLapBeforeAdd {newAccountRate.CustomerAccountId}, {newAccountRate.EffectiveStartDate}, {newAccountRate.EffectiveEndDate}").ToList();
                if (overlappingRates.Count > 0)
                {
                    customMessage = "There is an overlapping rate record existing in the system. Please enter valid period.";
                    error = "EffectiveEndDate";
                    return BadRequest(new { message = customMessage, errorPlace = error });
                }

                //validating whether it should create or extend the date
                var extendOrNot =
                    Database
                    .AccountRates
                    .FromSql($"uspCheckForExtendDateOrCreateNewRateRecord {newAccountRate.CustomerAccountId}, {newAccountRate.EffectiveStartDate}, {newAccountRate.EffectiveEndDate}, {newAccountRate.RatePerHour}").ToList();
                if (extendOrNot.Count > 0)
                {
                    customMessage = "You are advised to extend the existing rate record, instead of create a new one";
                    error = "update";

                    //help user to identify which rate should be extended 
                    return BadRequest(new { message = customMessage, updateID = extendOrNot[0].AccountRateId, errorPlace = error });
                }

                try
                {
                    Database.Add(newAccountRate);
                    Database.SaveChanges();
                }

                catch (Exception ex)
                {
                    customMessage = "Unable to create Account Rate because " + ex.InnerException.Message + ".";
                    return BadRequest(new { message = customMessage });
                }//End of try .. catch block on saving data
                 //Send back an OK with 200 status code

                return Ok(new
                {
                    message = "Saved Account Rate Record."
                });
            }
        }


        

        [Authorize("ADMIN")]
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromForm] IFormCollection data)
        {
            string customMessage = "";
            string error = "";

            int userId = int.Parse(User.FindFirst("userid").Value);

            AccountRate foundOneAccountRate = Database.AccountRates.SingleOrDefault(x => x.AccountRateId == id);
            
            if (foundOneAccountRate == null)
            {
                return NotFound(new { message = "Unable to find the rate information. " });
            }

            //checking the type of rate input, make sure it is decimal
            else if (validateDataType(data["rate"], data["start"], data["end"]) != null)
            {
                return validateDataType(data["rate"], data["start"], data["end"]);
            }
            else
            {
                foundOneAccountRate.RatePerHour = decimal.Parse(data["rate"]);
                foundOneAccountRate.EffectiveStartDate = DateTime.ParseExact(data["start"], "dd/MM/yyyy", CultureInfo.InvariantCulture);
                foundOneAccountRate.EffectiveEndDate = DateTime.ParseExact(data["end"], "dd/MM/yyyy", CultureInfo.InvariantCulture);
                foundOneAccountRate.UpdatedAt = _appDateTimeService.GetCurrentDateTime();
                foundOneAccountRate.UpdatedById = userId;

                //using fluentValidation to check
                if(validateProperty(foundOneAccountRate) != null)
                {
                    return validateProperty(foundOneAccountRate);
                }

                //validating the overlap using stored procedure
                var overlappingRates = 
                    Database
                    .AccountRates
                    .FromSql($"uspCheckOverLapBeforeUpdate {foundOneAccountRate.AccountRateId},{foundOneAccountRate.CustomerAccountId}, {foundOneAccountRate.EffectiveStartDate}, {foundOneAccountRate.EffectiveEndDate}").ToList();
                if (overlappingRates.Count > 0)
                {
                    customMessage = "There is an overlapping rate record existing in the system. Please enter valid period.";
                    error = "EffectiveEndDate";
                    return BadRequest(new { message = customMessage, errorPlace = error });
                }

                //Scenario 5
                //There is a gap between 2 rates record
                //when the user want to fill the gap, two rate records will be combined
                var extendOrNot =
                    Database
                    .AccountRates
                    .FromSql($"uspCheckForExtendDateOrCreateNewRateRecord {foundOneAccountRate.CustomerAccountId}, {foundOneAccountRate.EffectiveStartDate}, {foundOneAccountRate.EffectiveEndDate}, {foundOneAccountRate.RatePerHour}").ToList();
                if (extendOrNot.Count > 0)
                {
                    DateTime finalStartDate = extendOrNot[0].EffectiveStartDate <= foundOneAccountRate.EffectiveStartDate ? extendOrNot[0].EffectiveStartDate : foundOneAccountRate.EffectiveStartDate;
                    DateTime finalEndDate = extendOrNot[0].EffectiveEndDate >= foundOneAccountRate.EffectiveEndDate ? extendOrNot[0].EffectiveEndDate : foundOneAccountRate.EffectiveEndDate;

                    foundOneAccountRate.EffectiveStartDate = finalStartDate;
                    foundOneAccountRate.EffectiveEndDate = finalEndDate;
                    try
                    { 
                        //Delete the overlapping record
                        Database.Remove(extendOrNot[0]);
                        //Save the updated one
                        Database.Update(foundOneAccountRate);
                        Database.SaveChanges();
                    }
                    catch (Exception ex){
                        customMessage = "Unable to update lesson record because " + ex.InnerException.Message + ".";
                        return BadRequest(new { message = customMessage });
                    }
                    

                    customMessage = "The system has helped you to combine two rates into one, since they are of the same rate and cotinuous data";

                    //help user to identify which rate should be extended 
                    return Ok(new { message = customMessage});
                }


                try
                {  //Call the Update method and pass the foundOneStudent object into it
                    Database.Update(foundOneAccountRate);
                    //Tell the ApplicationDbContext object (referenced by the Database property)
                    //to make the changes permanent in the database.
                    Database.SaveChanges();
                }
                catch (Exception ex)
                {
                    customMessage = "Unable to update account rate because " + ex.InnerException.Message + ".";
                    return BadRequest(new { message = customMessage });
                }//End of try .. catch block on saving data
                 //Give a response with status 200. At the same time, attach 
                 //a JSON data
                return Ok(new { message = "The account rate has been updated successfully!" });
            }
        }
                
        

        public IActionResult validateDataType(string ratePerHour, string startDate, string endDate)
        {
            string customMessage = "";
            string error = "";
            decimal rateInput;
            DateTime start;
            DateTime end;

            if (!decimal.TryParse(ratePerHour, out rateInput))
            {
                customMessage = "Please enter a number for rate.";
                error = "RatePerHour";
                return BadRequest(new { message = customMessage, errorPlace = error });
            }
            else if (!DateTime.TryParseExact(startDate, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out start))
            {
                customMessage = "Please pick a valid start date from the calender.";
                error = "EffectiveStartDate";
                return BadRequest(new { message = customMessage, errorPlace = error });
            }
            //validating the date type of end date
            else if (!DateTime.TryParseExact(endDate, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out end))
            {
                customMessage = "Please pick a valid end date from the calender.";
                error = "EffectiveEndDate";
                return BadRequest(new { message = customMessage, errorPlace = error });
            }
            else
            {
                return null;
            }
        }



        public IActionResult validateProperty(AccountRate obj)
        {
            string error = "";
            string customMessage = ""; 

            //using fluentValidation to check
            AccountRate_Validation rateSentToValidate = new AccountRate_Validation();
            ValidationResult validationResult = rateSentToValidate.Validate(obj);
            if (!validationResult.IsValid)
            {
                error = validationResult.Errors[0].PropertyName;
                customMessage = validationResult.Errors[0].ErrorMessage;
                return BadRequest(new { message = customMessage, errorPlace = error });
            }
            else
            {
                return null;
            }
        }


    }
}
