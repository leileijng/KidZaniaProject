﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TMS.Data;
using TMS.Services;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TMS.APIs
{

    [Route("api/[controller]")]
    public class serverPageDemo02Controller  : Controller
    {
            //The following one member variable and one readonly property          
            //are required for every web api controller class. 
    private IAppDateTimeService _appDateTimeService;
    public ApplicationDbContext Database { get; } //Read-only Database property has been declared so that we can reference the given database object

    //The following constructor code pattern is required for every Web API     
    //controller class. 
    public serverPageDemo02Controller(IAppDateTimeService appDateTimeService,
        ApplicationDbContext database)
    {

        Database = database;
        _appDateTimeService = appDateTimeService;
    } //End of the constructor

    // GET: api/<controller>
    [HttpGet("test02/{custID}")]
        public IActionResult Get(int custID, [FromQuery] string pgNo, [FromQuery] string pgSize)
        {
            if ((pgNo == null) || (pgSize == null))
            {
                return BadRequest(new { message = "Query Parameter missiong!" });
            }
            int curPageNo = int.Parse(pgNo);
            int reqPageSize = int.Parse(pgSize);

            //Retrieve all the insructor accounts from pgNo = 2
            var queryResult = Database.AppUsers
                .Where(x => x.RoleId == 2)
                .OrderBy(x=> x.FullName)
                .Skip((curPageNo - 1) * reqPageSize).Take(reqPageSize)
                .Select(x=> new
                {
                    fullName = x.FullName,
                    email = x.UserName
                })
                .ToList();

            return Ok(queryResult);

        }


        // GET: api/<controller>
        [HttpGet("test02v2/{custID}")]
        public IActionResult GetPaging(int custID, [FromQuery] string pgNo, [FromQuery] string pgSize)
        {
            if ((pgNo == null) || (pgSize == null))
            {
                return BadRequest(new { message = "Query Parameter missiong!" });
            }
            int curPageNo = int.Parse(pgNo);
            int reqPageSize = int.Parse(pgSize);

            ////Retrieve all the insructor accounts from pgNo = 2
            //var queryResult = Database.AppUsers
            //    .Where(x => x.RoleId == 2)
            //    .OrderBy(x => x.FullName)
            //    .Skip((curPageNo - 1) * reqPageSize).Take(reqPageSize)
            //    .Select(x => new
            //    {
            //        fullName = x.FullName,
            //        email = x.UserName
            //    })
            //    .ToList();

            var allRecords = Database.AppUsers.Where(x=>x.RoleId == 2)
                .OrderBy(x => x.FullName).Select(x => new
                {
                    fullName = x.FullName,
                    email = x.UserName
                })
               .ToList();
            var queryResult = allRecords.Skip((curPageNo - 1) * reqPageSize).Take(reqPageSize);
            int totalNoRecords = allRecords.Count;
            int lastPage = (int)Math.Ceiling((double)totalNoRecords / reqPageSize);

            return Ok(new {
                totalPageCnt = lastPage,
                queryResult
            });

        }


        // GET api/<controller>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<controller>
        [HttpPost]
        public void Post([FromBody]string value)
        {
        }

        // PUT api/<controller>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
