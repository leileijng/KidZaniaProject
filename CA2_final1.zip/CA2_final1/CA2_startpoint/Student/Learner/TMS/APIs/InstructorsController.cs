﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.EntityFrameworkCore;
using TMS.Data;
using TMS.Models;
using TMS.Services;
using FluentValidation;
using FluentValidation.Results;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TMS.APIs
{
    [Route("api/[controller]")]
    public class InstructorsController : Controller
    {

        //The following one member variable and one readonly property          
        //are required for every web api controller class. 
        private IAppDateTimeService _appDateTimeService;
        public ApplicationDbContext Database { get; } //Read-only Database property has been declared so that we can reference the given database object

        //The following constructor code pattern is required for every Web API     
        //controller class. 
        public InstructorsController(IAppDateTimeService appDateTimeService,
            ApplicationDbContext database)
        {

            Database = database;
            _appDateTimeService = appDateTimeService;
        } //End of the constructor





        //***************
        //GET api
        //***************
        [Authorize("ADMIN")]
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            List<object> InstructorAccount = new List<object>();
            bool exist = true;
            var instructorList = Database.InstructorAccounts.Include(x => x.Instructor).Include(account => account.CreatedBy).Include(account => account.CustomerAccount)
                .Where(account => account.CustomerAccountId == id).ToList();
            if (instructorList.Count < 1 )
            {
                exist = false;
            }
            else
            {
                foreach (var oneInstructors in instructorList)
                {
                    InstructorAccount.Add(new

                    {
                        accountName = oneInstructors.CustomerAccount.AccountName,
                        customerAccountId = oneInstructors.CustomerAccountId,
                        instructorAccountId = oneInstructors.InstructorAccountId,
                        instructorId = oneInstructors.InstructorId,
                        fullname = oneInstructors.Instructor.FullName,
                        userName = oneInstructors.Instructor.UserName,
                        wageRate = oneInstructors.WageRate,
                        createdAt = oneInstructors.CreatedAt,
                        createdBy = oneInstructors.CreatedBy.FullName
                    });
                }
            }
            
            return Ok(new {
                records = InstructorAccount,
                exist
            });

        }



        //***************
        //GET api/AssignInstructor/ID
        //***************
        [Authorize("ADMIN")]
        [HttpGet("AssignInstructor/{custID}")]
        public IActionResult AssignInstructor(int custID, [FromQuery] string pgNo, [FromQuery] string pgSize)
        {
            if ((pgNo == null) || (pgSize == null))
            {
                return BadRequest(new { message = "Query Parameter Missing!" });
            };
            int curPageNo = int.Parse(pgNo);
            int regPageSize = int.Parse(pgSize);

            var allRecords = Database.AppUsers
                                    .Where(x => x.RoleId == 2)
                                    .OrderBy(x => x.FullName)
                                    .Select(x => new
                                    {
                                        fullName = x.FullName,
                                        email = x.UserName,
                                        id = x.Id,
                                        hasAssigned = Database.InstructorAccounts.SingleOrDefault(y=>y.CustomerAccountId == custID && y.InstructorId == x.Id)                                      
                                    })
                                    .ToList();
            CustomerAccount oneCust = new CustomerAccount();
            oneCust = Database.CustomerAccounts.SingleOrDefault(y => y.CustomerAccountId == custID);
            string custName = oneCust.AccountName;
            var queryResult = allRecords.Skip(regPageSize * (curPageNo - 1)).Take(regPageSize);
            int totalNoRecords = allRecords.Count();
            int lastPage = (int)Math.Ceiling((double)totalNoRecords / regPageSize);


            return Ok(new
            {
                totalPageCnt = lastPage,
                records = queryResult,
                custName
            });
        }        
        
        
        
        
        //***************
        //GET api/AssignInstructor/ID
        //***************
        [Authorize("ADMIN")]
        [HttpGet("GetCustomerList/{instID}")]
        public IActionResult GetCustomerList(int instID)
        {
            bool hasCust = true;
            List<string> custNameList = new List<string>();
            List<int> custIDList = new List<int>();
            List<InstructorAccount> InstrList = Database.InstructorAccounts.Include(x => x.CustomerAccount).Where(x => x.InstructorId == instID).ToList();
            if (InstrList == null)
            {
                hasCust = false;
            }
            else
            {
                foreach( InstructorAccount oneInstr in InstrList)
                {
                    custIDList.Add(oneInstr.CustomerAccountId);
                    custNameList.Add(oneInstr.CustomerAccount.AccountName);
                }
            }
            return Ok(new
            {
                hasCust,
                custIDList,
                custNameList
            });

        }




        //***************
        //GET api/Instructors/Delete
        //***************
        [Authorize("ADMIN")]
        [HttpDelete("UnAssignInstructorFromCustomerAccount/")]
        public IActionResult UnAssignInstructorFromCustomerAccount([FromQuery] string value)
        {
            string customMessage = "";
            List<string> listOfId = new List<string>();
            try
            {
                 listOfId = value.Split(',').ToList();
            }
            catch (Exception ex)
            {
                customMessage = "You didn't select any instructor!";
                return BadRequest(new { message = customMessage });
            }
            List<InstructorAccount> instructorCustomerAccountList = new List<InstructorAccount>();

            try
            {
                instructorCustomerAccountList = Database.InstructorAccounts.Where(record => listOfId.Contains(record.InstructorAccountId.ToString())).ToList();

                if (instructorCustomerAccountList != null)
                {
                    Database.InstructorAccounts.RemoveRange(instructorCustomerAccountList);
                }

                Database.SaveChanges();
            }
            catch (Exception ex)
            {
                customMessage = "Unable to delete Account record.";
                return BadRequest(new { message = customMessage });
            }

            return Ok(new { message = "Deleted Account record" });
        }



        [Authorize("ADMIN")]
        [HttpPost("AssignInstuctorAccount/{custID}")]
        public IActionResult AssignInstuctorAccount([FromForm] IFormCollection data, int custID)
        {
            int userId = int.Parse(User.FindFirst("userid").Value);
            
            bool fail = false;
            string errorMsg = "";
            List<int> failIDs  = new List<int>();
            List<string> failNames = new List<string>();
            //Check whether have data inside => user select the instructor or not
            if (data["instructorIds[]"].Count > 0)
            {
                for (int i = 0; i < data["instructorIds[]"].Count; i++)
                {
                    InstructorAccount newInstructor = new InstructorAccount();
                    
                    //check datatype of instructor Id and wage
                    if (!validateDataType(data["wageRates[]"][i]))
                    {
                        fail = true;
                        failIDs.Add(int.Parse(data["instructorIds[]"][i]));
                        failNames.Add(Database.AppUsers.SingleOrDefault(x => x.Id == int.Parse(data["instructorIds[]"][i])).FullName);
                    }

                    else
                    {
                        //assign the collected data into newInstructor
                        newInstructor.CustomerAccountId = custID;
                        newInstructor.InstructorId = int.Parse(data["instructorIds[]"][i]);
                        newInstructor.WageRate = Convert.ToDecimal(data["wageRates[]"][i]);
                        newInstructor.CreatedAt = _appDateTimeService.GetCurrentDateTime();
                        newInstructor.CreatedById = userId;

                        //using fluentValidation to check each property 
                        if (!validateProperty(newInstructor))
                        {
                            fail = true;
                            failIDs.Add(newInstructor.InstructorId);
                            failNames.Add(" " + Database.AppUsers.SingleOrDefault(x => x.Id == int.Parse(data["instructorIds[]"][i])).FullName);
                        }
                        //if the fluentValidation is no problem
                        else
                        {
                            try
                            {
                                Database.Add(newInstructor);
                                Database.SaveChanges();
                            }
                            catch (Exception ex)
                            {
                                //Fail for internal error (unknown error position)
                                fail = true;
                                errorMsg += ex.InnerException.Message;
                            }//End of Try..Catch block
                        }
                    }
                }
                if (fail)
                {
                    return BadRequest(new
                    {
                        failIDs,
                        failNames,
                        errorMsg = "These are the instructors FAILED to assign:  "
                    });
                }
                return Ok(new { msg = "You have successfully assigned all instructors!" });
            }

            else
            {
                return BadRequest(new { errorMsg = "You did not assign any instructor to the customer." });
            }
        }






        private bool validateDataType(string inWage)
        {
            decimal wage;
            if (!decimal.TryParse(inWage, out wage))
            {
                return false;
            }
            else
            {
                return true;
            }
        }



        private bool validateProperty(InstructorAccount obj)
        {
            string customMessage = "";
            //using fluentValidation to check
            InstructorAccount_Validation instructor = new InstructorAccount_Validation();
            ValidationResult validationResult = instructor.Validate(obj);
            if (!validationResult.IsValid)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}