﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.EntityFrameworkCore;
using TMS.Data;
using TMS.Models;
using TMS.Services;
using FluentValidation;
using FluentValidation.Results;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TMS.APIs
{
    [Route("api/[controller]")]
    public class AccountTimeTablesController : Controller
    {       
        //The following one member variable and one readonly property are required for every web api controller class. 
        private IAppDateTimeService _appDateTimeService;
        public ApplicationDbContext Database { get; }
        //Read-only Database property has been declared so that we can reference the given database object

        //The following constructor code pattern is required for every Web API controller class. 

        public AccountTimeTablesController(IAppDateTimeService appDateTimeService,
            ApplicationDbContext database)
        {

            Database = database;
            _appDateTimeService = appDateTimeService;
        } //End of the constructor

        // GET: api/<controller>
        [Authorize("ADMIN")]
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            //SingleOrDefault returns either null or an object
            List<AccountTimeTable> findTimeTables = Database.AccountTimeTable.Include(x => x.CreatedBy).Include(x => x.UpdatedBy).Include(x => x.AccountRate).Where(x => x.AccountRateId == id).ToList();
            List<object> timeTableList = new List<object>();
            bool recordExist = true;
            if (findTimeTables.Count == 0)
            {
                recordExist = false;
            }
            else
            {
                foreach (AccountTimeTable oneTimeTable in findTimeTables)
                {
                    string day = findDay(oneTimeTable.DayOfWeekNumber);

                    TimeSpan span = TimeSpan.FromMinutes(oneTimeTable.StartTimeInMinutes);
                    DateTime time = DateTime.Today + span;
                    string startTimeInHHMM = time.ToString("hh:mm tt");

                    span = TimeSpan.FromMinutes(oneTimeTable.EndTimeInMinutes);
                    time = DateTime.Today + span;
                    string endTimeInHHMM = time.ToString("hh:mm tt");

                    string startDate = Convert.ToDateTime(oneTimeTable.EffectiveStartDate).ToString("dd/MM/yyyy");
                    string endDate = Convert.ToDateTime(oneTimeTable.EffectiveEndDate).ToString("dd/MM/yyyy");
                    //string createdAt = Convert.ToDateTime(oneTimeTable.EffectiveStartDate).ToString("dd/MM/yyyy");
                    //string updatedAt = Convert.ToDateTime(oneTimeTable.EffectiveStartDate).ToString("dd/MM/yyyy");
                    timeTableList.Add(new
                    {
                        id = oneTimeTable.AccountTimeTableId,
                        day,
                        startTime = startTimeInHHMM,
                        endTime = endTimeInHHMM,
                        startDate,
                        endDate,
                        visibility = oneTimeTable.IsVisible
                    });
                }
                //end of creation of the anonymous type response object
            }//end of if..else
            return Ok(new
            {
                timeTableList,
                recordExist
            });
        }




        [Authorize("ADMIN")]
        [HttpGet("GetSummaryForOneTimeTable/{id}")]
        public IActionResult GetSummaryForOneTimeTable(int id)
        {
            //SingleOrDefault returns either null or an object
            var oneTimeTable = Database.AccountTimeTable.SingleOrDefault(x => x.AccountTimeTableId == id);
            if (oneTimeTable == null)
            {
                return NotFound(new { message = "Unable to retrieve timetable data" });
            }
            else
            {
                TimeSpan startSpan = TimeSpan.FromMinutes(oneTimeTable.StartTimeInMinutes);
                DateTime time = DateTime.Today + startSpan;
                string startTimeInHHMM = time.ToString("hh:mm tt");

                TimeSpan endSpan = TimeSpan.FromMinutes(oneTimeTable.EndTimeInMinutes);
                time = DateTime.Today + endSpan;
                string endTimeInHHMM = time.ToString("hh:mm tt");

                string day = findDay(oneTimeTable.DayOfWeekNumber);
                var response = new
                {
                    day,
                    dayValue = oneTimeTable.DayOfWeekNumber,
                    startTime = startTimeInHHMM,
                    endTime = endTimeInHHMM,
                    startTime24 = startSpan.ToString().Substring(0, 5),
                    endTime24 = endSpan.ToString().Substring(0, 5),
                    startDay = Convert.ToDateTime(oneTimeTable.EffectiveStartDate).ToString("dd/MM/yyyy"),
                    endDay = Convert.ToDateTime(oneTimeTable.EffectiveEndDate).ToString("dd/MM/yyyy"),
                    visibility = oneTimeTable.IsVisible
                };
                //end of creation of the anonymous type response object
                return Ok(response);
            }//end of if..else
        }


        

        // POST api/<controller>
        [Authorize("ADMIN")]
        [HttpPost("{rateId}")]
        public IActionResult Post([FromForm] IFormCollection data, int rateId)
        {
            int userId = int.Parse(User.FindFirst("userid").Value);
            string customMessage = "";
            bool reject = false;
            bool createAnyway = Convert.ToBoolean(data["createAnyway"]);

            //valildate the datatype 
            if (validateDataType(data["day"], data["startTime"], data["endTime"], data["startDate"], data["endDate"], data["visibility"]) != null)
            {
                List<string> errorInfo = validateDataType(data["day"], data["startTime"], data["endTime"], data["startDate"], data["endDate"], data["visibility"]);
                return BadRequest(new
                {
                    error = errorInfo[0],
                    errorMsg = errorInfo[1]
                });
            }
            
            AccountTimeTable newTimeTable = new AccountTimeTable();
            newTimeTable.AccountRateId = rateId;

            newTimeTable.DayOfWeekNumber = int.Parse(data["day"]);

            DateTime startTime =  DateTime.ParseExact(data["startTime"], "HH:mm", CultureInfo.InvariantCulture);
            newTimeTable.StartTimeInMinutes = (startTime.Hour * 60) + startTime.Minute;
            DateTime endTime = DateTime.ParseExact(data["endTime"], "HH:mm", CultureInfo.InvariantCulture);
            newTimeTable.EndTimeInMinutes = (endTime.Hour * 60) + endTime.Minute;
            newTimeTable.EffectiveStartDate = DateTime.ParseExact(data["startDate"], "dd/MM/yyyy", CultureInfo.InvariantCulture);
            newTimeTable.EffectiveEndDate = DateTime.ParseExact(data["endDate"], "dd/MM/yyyy", CultureInfo.InvariantCulture);

            newTimeTable.IsVisible = Convert.ToBoolean(data["visibility"]);
            newTimeTable.CreatedById = userId;
            newTimeTable.UpdatedById = userId;
            newTimeTable.UpdatedAt = _appDateTimeService.GetCurrentDateTime();
            newTimeTable.CreatedAt = _appDateTimeService.GetCurrentDateTime();

            //link to AccountRate, to make sure fluentValidation can retrieve startdate and enddate from accountrate
            newTimeTable.AccountRate = Database.AccountRates.SingleOrDefault(x => x.AccountRateId == rateId);
            //validate the account timetable properties
            //use fluent validation
            //using fluentValidation to check each property 
            if (validateProperty(newTimeTable) != null)
            {
                List<string> errorInfo = validateProperty(newTimeTable);
                return BadRequest(new
                {
                    error = errorInfo[0],
                    errorMsg = errorInfo[1]
                });
            }


            //validating whether it has conflict with other timetable record
            var identicalRecord =
                Database
                .AccountTimeTable
                .FromSql($"uspAccountTimeTableCheckIdenticalBeforeAdd {newTimeTable.AccountRateId}, {newTimeTable.DayOfWeekNumber}, {newTimeTable.EffectiveStartDate}, {newTimeTable.EffectiveEndDate}, {newTimeTable.StartTimeInMinutes}, {newTimeTable.EndTimeInMinutes}").ToList();
            if (identicalRecord.Count > 0)
            {
                customMessage = "Failed to create record. Your account timetable is the same as the following existing record.";
                reject = true;
                //help user to identify which rate should be extended 
                return BadRequest(new { errorMsg = customMessage, identicalID = identicalRecord[0].AccountTimeTableId, reject });
            }

            if (!createAnyway) //createAnyway wil now check this stored procedure
            {
                //validating whether it has conflict with other timetable record
                var overlapRecords =
                    Database
                    .AccountTimeTable
                    .FromSql($"uspTimeTableCheckOverlapBeforeAdd {newTimeTable.AccountRateId}, {newTimeTable.DayOfWeekNumber}, {newTimeTable.EffectiveStartDate}, {newTimeTable.EffectiveEndDate}, {newTimeTable.StartTimeInMinutes}, {newTimeTable.EndTimeInMinutes}").ToList();
                if (overlapRecords.Count > 0)
                {
                    List<int> overlapIDs = new List<int>();
                    foreach (AccountTimeTable oneTimetable in overlapRecords)
                    {
                        overlapIDs.Add(oneTimetable.AccountTimeTableId);
                    }
                    customMessage = "Your timetable overlaps with the following existing timetable. Continue creating?";
                    reject = false;
                    //help user to identify which rate should be extended 
                    return BadRequest(new { errorMsg = customMessage, overlapIDs, reject });
                }
            }
             
            try
            {
                Database.Add(newTimeTable);
                //Tell the Database to make the changes permanent (create record)
                Database.SaveChanges();
            }
            catch (Exception ex)
            {
                    customMessage = "Unable to create timetable because " + ex.InnerException.Message + ".";
                    return BadRequest(new { errorMsg = customMessage });
                
            }//End of try .. catch block on saving data
             //Send back an OK with 200 status code

            return Ok(new
            {
                message = "New TimeTable Record has been created successfully."
            });
        }


        [Authorize("ADMIN")]
        [HttpPut("{timetTableId}")]
        public IActionResult Put(int timetTableId, [FromForm] IFormCollection data)
        {
            string customMessage = "";
            bool reject = false;
            bool updateAnyway = bool.Parse(data["updateAnyway"]);
            int userId = int.Parse(User.FindFirst("userid").Value);

            AccountTimeTable foundOneTimeTable = Database.AccountTimeTable.Include(x=>x.AccountRate).SingleOrDefault(x => x.AccountTimeTableId == timetTableId);

            if (foundOneTimeTable == null)
            {
                return NotFound(new { message = "Unable to find the rate information. " });
            }
            else
            {
                //valildate the datatype 
                if (validateDataType(data["day"], data["startTime"], data["endTime"], data["startDate"], data["endDate"], data["visibility"]) != null)
                {
                    List<string> errorInfo = validateDataType(data["day"], data["startTime"], data["endTime"], data["startDate"], data["endDate"], data["visibility"]);
                    return BadRequest(new
                    {
                        error = errorInfo[0],
                        errorMsg = errorInfo[1]
                    });
                }


                foundOneTimeTable.DayOfWeekNumber = int.Parse(data["day"]);

                DateTime startTime = DateTime.ParseExact(data["startTime"], "HH:mm", CultureInfo.InvariantCulture);
                foundOneTimeTable.StartTimeInMinutes = (startTime.Hour * 60) + startTime.Minute;

                DateTime endTime = DateTime.ParseExact(data["endTime"], "HH:mm", CultureInfo.InvariantCulture);
                foundOneTimeTable.EndTimeInMinutes = (endTime.Hour * 60) + endTime.Minute;

                foundOneTimeTable.EffectiveStartDate = DateTime.ParseExact(data["startDate"], "dd/MM/yyyy", CultureInfo.InvariantCulture);
                foundOneTimeTable.EffectiveEndDate = DateTime.ParseExact(data["endDate"], "dd/MM/yyyy", CultureInfo.InvariantCulture);

                foundOneTimeTable.IsVisible = Convert.ToBoolean(data["visibility"]);
                foundOneTimeTable.UpdatedAt = _appDateTimeService.GetCurrentDateTime();
                foundOneTimeTable.UpdatedById = userId;


                //validate the account timetable properties
                //use fluent validation
                //using fluentValidation to check each property 
                if (validateProperty(foundOneTimeTable) != null)
                {
                    List<string> errorInfo = validateProperty(foundOneTimeTable);
                    return BadRequest(new
                    {
                        error = errorInfo[0],
                        errorMsg = errorInfo[1]
                    });
                }



                //validating whether it has conflict with other timetable record
                var identicalRecord =
                    Database
                    .AccountTimeTable
                    .FromSql($"uspAccountTimeTableCheckIdenticalBeforeUpdate {foundOneTimeTable.AccountTimeTableId}, {foundOneTimeTable.AccountRateId}, {foundOneTimeTable.DayOfWeekNumber}, {foundOneTimeTable.EffectiveStartDate}, {foundOneTimeTable.EffectiveEndDate}, {foundOneTimeTable.StartTimeInMinutes}, {foundOneTimeTable.EndTimeInMinutes}").ToList();
                if (identicalRecord.Count > 0)
                {
                    customMessage = "Failed to update record. Your account timetable is the same as the following existing record.";
                    reject = true;
                    //help user to identify which rate should be extended 
                    return BadRequest(new { message = customMessage, identicalID = identicalRecord[0].AccountTimeTableId, reject });
                }


                if (!updateAnyway) //createAnyway wil now check this stored procedure
                {
                    //validating whether it has conflict with other timetable record
                    var overlapRecords =
                        Database
                        .AccountTimeTable
                        .FromSql($"uspTimeTableCheckOverlapBeforeUpdate {foundOneTimeTable.AccountTimeTableId}, {foundOneTimeTable.AccountRateId}, {foundOneTimeTable.DayOfWeekNumber}, {foundOneTimeTable.EffectiveStartDate}, {foundOneTimeTable.EffectiveEndDate}, {foundOneTimeTable.StartTimeInMinutes}, {foundOneTimeTable.EndTimeInMinutes}").ToList();
                    if (overlapRecords.Count > 0)
                    {
                        List<int> overlapIDs = new List<int>();
                        foreach (AccountTimeTable oneTimetable in overlapRecords)
                        {
                            overlapIDs.Add(oneTimetable.AccountTimeTableId);
                        }
                        customMessage = "Your timetable overlaps with the following existing timetable. Continue updating?";
                        reject = false;
                        //help user to identify which rate should be extended 
                        return BadRequest(new { message = customMessage, overlapIDs, reject });
                    }
                }


                try
                {  //Call the Update method and pass the foundOneStudent object into it
                    Database.Update(foundOneTimeTable);
                    //Tell the ApplicationDbContext object (referenced by the Database property)
                    //to make the changes permanent in the database.
                    Database.SaveChanges();
                }
                catch (Exception ex)
                {
                    customMessage = "Unable to update timetable because " + ex.InnerException.Message + ".";
                    return BadRequest(new { message = customMessage });
                }//End of try .. catch block on saving data
                 //Give a response with status 200. At the same time, attach 
                 //a JSON data
                return Ok(new { message = "The timetable has been updated successfully!" });
            }
        }


        [Authorize("ADMIN")]
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            string customMessage = "";

            var foundOneTimeTable = Database.AccountTimeTable.SingleOrDefault(x => x.AccountTimeTableId == id);

            if (foundOneTimeTable == null)
            {
                return NotFound(new { message = "Cannot find the time table record! Please refresh the page!" });
            }
            //Call the remove method, pass the foundOneAccount object into it
            //so that the Database object knows what to remove from the database.
            try
            {
                Database.Remove(foundOneTimeTable);
                //Tell the db model to commit/persist the changes to the database, 
                //I use the following command.
                Database.SaveChanges();
            }
            catch (Exception ex)
            {
                customMessage = "Unable to delete timetable because " + ex.InnerException.Message + ".";
                return BadRequest(new { message = customMessage });
            }//End of try .. catch block on manage data

            return Ok(new { message = "Deleted timetable successfully" });
        }//end of Delete() Web API method


        public string findDay (int numberOfDay)
        {
            switch (numberOfDay)
            {
                case (1):
                    return "Sunday";
                case (2):
                    return "Monday";
                case (3):
                    return "Tuesday";
                case (4):
                    return "Wednesday";
                case (5):
                    return "Thursday";
                case (6):
                    return "Friday";
                case (7):
                    return "Saturday";
                default:
                    return "N.A.";
            }
        }



        private List<string> validateDataType(string dayOfWeek, string inStartTime, string inEndTime, string inStartDate, string inEndDate, string inVisibility)
        {
            int day;
            DateTime startTime;
            DateTime endTime;
            DateTime startDate;
            DateTime endDate;
            bool visibility;

            string error;
            string errorMsg;
            List<string> errorInfo = new List<string>();

            if (!int.TryParse(dayOfWeek, out day))
            {
                error = "DayOfWeekNumber";
                errorMsg = "Day of week must be integer!";
                errorInfo.Add(error);
                errorInfo.Add(errorMsg);
                return errorInfo;
            }
            else if (!DateTime.TryParseExact(inStartTime, "HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out startTime))
            {
                error = "StartTimeInMinutes";
                errorMsg = "You did not provide valid start time!";
                errorInfo.Add(error);
                errorInfo.Add(errorMsg);
                return errorInfo;
            }
            else if (!DateTime.TryParseExact(inEndTime, "HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out endTime))
            {
                error = "EndTimeInMinutes";
                errorMsg = "You did not provide valid end time!";
                errorInfo.Add(error);
                errorInfo.Add(errorMsg);
                return errorInfo;
            }
            else if (!DateTime.TryParseExact(inStartDate, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out startDate))
            {
                error = "EffectiveStartDate";
                errorMsg = "You did not provide valid start date!";
                errorInfo.Add(error);
                errorInfo.Add(errorMsg);
                return errorInfo;
            }
            else if (!DateTime.TryParseExact(inEndDate, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out endDate))
            {
                error = "EffectiveEndDate";
                errorMsg = "You did not provide valid end date!";
                errorInfo.Add(error);
                errorInfo.Add(errorMsg);
                return errorInfo;
            }
            else if (!Boolean.TryParse(inVisibility, out visibility))
            {
                error = "IsVisible";
                errorMsg = "The slider button has problem!";
                errorInfo.Add(error);
                errorInfo.Add(errorMsg);
                return errorInfo;
            }
            else
            {
                return null;
            }
        }



        private List<string> validateProperty(AccountTimeTable obj)
        {
            string error = "";
            string customMessage = "";
            List<string> errorInfo = new List<string>();
            //using fluentValidation to check
            AccountTimeTable_Validation timetable = new AccountTimeTable_Validation();
            ValidationResult validationResult = timetable.Validate(obj);
            if (!validationResult.IsValid)
            {
                error = validationResult.Errors[0].PropertyName;
                customMessage = validationResult.Errors[0].ErrorMessage;
                errorInfo.Add(error);
                errorInfo.Add(customMessage);
                return errorInfo;
            }
            else
            {
                return null;
            }
        }

    }
}
