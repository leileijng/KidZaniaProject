﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.EntityFrameworkCore;
using TMS.Data;
using TMS.Models;
using TMS.Services;
using FluentValidation;
using FluentValidation.Results;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TMS.APIs
{
    [Route("api/[controller]")]
    public class CustomerAccountComments : Controller
    {
        //The following one member variable and one readonly property          
        //are required for every web api controller class. 
        private IAppDateTimeService _appDateTimeService;
        public ApplicationDbContext Database { get; } //Read-only Database property has been declared so that we can reference the given database object

        //The following constructor code pattern is required for every Web API     
        //controller class. 
        public CustomerAccountComments(IAppDateTimeService appDateTimeService,
            ApplicationDbContext database)
        {

            Database = database;
            _appDateTimeService = appDateTimeService;
        } //End of the constructor

        /// <summary>
        /// Get Comments
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        //GET api/<controller>/5
         [HttpGet("GetCustomerName/{customerid}")]
         public IActionResult GetComments(int customerid)
          {
            CustomerAccount newCustomer = Database.CustomerAccounts.SingleOrDefault(x => x.CustomerAccountId == customerid);
            
            if(newCustomer == null)
            {
                return BadRequest(new { message = "Cannot find this customer! Something wrong with front end" });
            }

            return Ok(new
            {
                customer = newCustomer.AccountName
            });
        }



        [HttpGet("GetCommentsHierarchy/{id}")]
        public IActionResult GetCommentsHierarchy(int id)
        { //Create an List of objects first, records.
            List<object> records = new List<object>();

            //Requires the namespace System.Data.Common
            DbCommand cmd = Database.Database.GetDbConnection().CreateCommand();
            cmd.Connection.Open();
            cmd.CommandText = "uspGetCommentsHierarchy";
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            
            //Pass the page number value to the stored procedure's @pageNo parameter 
            DbParameter parameter = cmd.CreateParameter();
            parameter.DbType = System.Data.DbType.Int32;
            parameter.ParameterName = "customerId";
            parameter.Value = id;
            cmd.Parameters.Add(parameter);

            DbDataReader dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    //Get each column values
                    int commentId = int.Parse(dr["customerAccountCommentId"].ToString());
                    string comments = dr["Comment"].ToString();
                    //Applying inline if else to produce 0 if NULL is detected
                    int parentId = dr["ParentId"] == DBNull.Value ? 0 : int.Parse(dr["ParentId"].ToString());

                    //Create an anonymous object and at the same time
                    //add it into the records List collection
                    records.Add(new
                    {
                        id = commentId,
                        comment = comments,
                        replyTo = parentId
                    });
                }
            }
            else
            {
                records = null;
            }
            cmd.Connection.Close();
            return new JsonResult(records);
        }//End of GetEmployeeHierarchy


        // Post api/CustomerAccountComments/
        [HttpPost]
        public IActionResult Post([FromForm] IFormCollection data)
        {
            int userId = int.Parse(User.FindFirst("userid").Value);
            string customMessage = "";
            
            CustomerAccountComment newComment = new CustomerAccountComment();
            newComment.Comment = data["comment"];
            if (data["parentId"] != "0")
            {
                newComment.ParentId = int.Parse(data["parentId"]);
            }
            newComment.CustomerAccountId = int.Parse(data["customerId"]);
            newComment.CreatedById = userId;
            newComment.CreatedAt = _appDateTimeService.GetCurrentDateTime();
            newComment.UpdatedAt = _appDateTimeService.GetCurrentDateTime();

            if (validateCustomerAccountProperty(newComment) != null)
            {
                return validateCustomerAccountProperty(newComment);
            }

            try
            {
                //Add the newStudent object into the Database.
                //Equivalent command can be Database.Students.Add(newStudent)
                Database.Add(newComment);
                //Tell the Database to make the changes permanent (create record)
                Database.SaveChanges();
            }
            catch (Exception ex)
            {
                    customMessage = "The request could not be processed " +
                                   "due to internal errors. Please, try it later";
                    return BadRequest(new { message = customMessage });
                
            }//End of try .. catch block on saving data

            return Ok(new
            {
                message = "Saved Comment Record."
            });
        }//End of Post web api

        public IActionResult validateCustomerAccountProperty(CustomerAccountComment obj)
        {
            string error = "";
            string customMessage = "";

            //using fluentValidation to check
            CustomerAccountComment_Validation commentSentToValidate = new CustomerAccountComment_Validation();
            ValidationResult validationResult = commentSentToValidate.Validate(obj);
            if (!validationResult.IsValid)
            {
                error = validationResult.Errors[0].PropertyName;
                customMessage = validationResult.Errors[0].ErrorMessage;
                return BadRequest(new { message = customMessage, errorPlace = error });
            }
            else
            {
                return null;
            }
        }

    }
}
