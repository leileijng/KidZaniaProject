﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.EntityFrameworkCore;
using TMS.Data;
using TMS.Models;
using TMS.Services;
using FluentValidation;
using FluentValidation.Results;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TMS.APIs
{
    [Route("api/[controller]")]
    public class CustomerAccountsController : Controller
    {
        //The following one member variable and one readonly property          
        //are required for every web api controller class. 
        private IAppDateTimeService _appDateTimeService;
        public ApplicationDbContext Database { get; } //Read-only Database property has been declared so that we can reference the given database object

        //The following constructor code pattern is required for every Web API     
        //controller class. 
        public CustomerAccountsController(IAppDateTimeService appDateTimeService,
            ApplicationDbContext database)
        {

            Database = database;
            _appDateTimeService = appDateTimeService;
        } //End of the constructor



        [Authorize("ADMIN")]
        [HttpGet("GetCustomerAccountsPageByPage")]
        public JsonResult GetCustomerAccountsPageByPage(
                 [FromQuery]QueryPagingParametersForCustomerAccount inParameters)
        {
            int pageSize = 10;
            int totalPage = 0;
            int startRecord = 0;
            int endRecord = 0;
            int currentPage = 0;

            string fieldToSort = inParameters.sort_col; //column name
            string sortDirection = inParameters.sort_order; //"ASC" or "DESC" 

            List<object> recordList = new List<object>();
            int totalRecords = 0;
            if (ModelState.IsValid)
            {
                currentPage = Int32.Parse(inParameters.page_number.ToString());
                pageSize = Int32.Parse(inParameters.per_page.ToString());
            }
            else
            {
                currentPage = 1;
                pageSize = 10;
            }
            if (currentPage == 1)
            {
                startRecord = 1;
            }
            else
            {
                startRecord = (currentPage * pageSize) + 1;
            }
            endRecord = pageSize * currentPage;

            //To use DbCommand class, you need the namespace System.Data.Common 
            //Create a new DbCommand type object 
            DbCommand cmd = Database.Database.GetDbConnection().CreateCommand();
            //Tell the DbCommand object, cmd to open a connection to db  
            cmd.Connection.Open();
            //Pass the SQL to the DbCommand type object, cmd. 
            //Let the DbCommand type object cmd know that this is a stored procedure.    
            cmd.CommandText = "dbo.uspSelectCustomerAccount";
            //Tell the DbCommand object, cmd that this is a stored procedure.
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            //Pass the page number value to the stored procedure's @pageNo parameter 
            DbParameter parameter = cmd.CreateParameter();
            parameter.DbType = System.Data.DbType.Int32;
            parameter.ParameterName = "pageNo";
            parameter.Value = currentPage;
            cmd.Parameters.Add(parameter);
            //Pass the page size value to the stored procedure's @pageSize parameter 
            parameter = cmd.CreateParameter();
            parameter.DbType = System.Data.DbType.Int32;
            parameter.ParameterName = "pageSize";
            parameter.Value = pageSize;
            cmd.Parameters.Add(parameter);


            //Pass the field to sort information to the procedures @sortColumn 
            //parameter 
            parameter = cmd.CreateParameter();
            parameter.DbType = System.Data.DbType.String;
            //Hard code this here because not getting it from the client-side 
            parameter.ParameterName = "sortColumn";
            parameter.Value = fieldToSort;//DONEAT        
            cmd.Parameters.Add(parameter);


            //Pass the field to sort order to the procedures @sortOrder 
            //parameter 
            parameter = cmd.CreateParameter();
            parameter.DbType = System.Data.DbType.String;
            //Hard code this here because I did not provide code to obtain from clientside         
            parameter.ParameterName = "sortOrder";
            parameter.Value = sortDirection;//ASC      
            cmd.Parameters.Add(parameter);

            DbDataReader dr = cmd.ExecuteReader();//This is the part where SQL is sent to DB    
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    //Get each column values               
                    int recordId = int.Parse(dr["CustomerAccountId"].ToString());
                    int rowNumber = int.Parse(dr["ROWNUM"].ToString());
                    string accountName = dr["AccountName"].ToString();
                    bool isVisible = Convert.ToBoolean(dr["IsVisible"].ToString());
                    string createdBy = dr["CreatedBy"].ToString();
                    string updatedBy = dr["UpdatedBy"].ToString();
                    string createdAt = Convert.ToDateTime(dr["CreatedAt"]).ToString("dd/MM/yyyy");
                    string updatedAt = Convert.ToDateTime(dr["UpdatedAt"]).ToString("dd/MM/yyyy");
                    
                    //totalRecords variable is not included inside the anonymous type
                    //object creation. Instead it will be used outside the loop to 
                    //calculate the "total number of pages" which is needed by the client
                    //side to decide how paging buttons should be created
                    totalRecords = int.Parse(dr["TotalCount"].ToString());

                    //Create an anonymous object and at the same time 
                    //add it into the recordList collection    
                    recordList.Add(new
                    {
                        id = recordId,
                        rowNumber = rowNumber,
                        accountName = accountName,
                        isVisible = isVisible,
                        createdBy = createdBy,
                        createdAt = createdAt,
                        updatedBy = updatedBy,
                        updatedAt = updatedAt
                    });
                }
            }
            cmd.Connection.Close();

            totalPage = (int)Math.Ceiling((double)totalRecords / pageSize);

            object finalResult = new object();
            string nextPageUrl = "";
            string prevPageUrl = "";

            if (currentPage == 1)
            {
                prevPageUrl = null;
                nextPageUrl = "/API/CustomerAccounts/GetCustomerAccountsPageByPage?per_page=" +
                    pageSize.ToString() + "&page_number=" + (currentPage + 1);
            }
            else
            {
                prevPageUrl = "/API/CustomerAccounts/GetCustomerAccountsPageByPage?per_page=" +
                    pageSize.ToString() + "&page_number=" + (currentPage - 1);
                if (currentPage == totalPage)
                {
                    nextPageUrl = null;
                }
                else
                {
                    nextPageUrl = "/API/CustomerAccounts/GetCustomerAccountsPageByPage?per_page=" +
                        pageSize.ToString() + "&page=" + (currentPage + 1);
                }
            }
            finalResult = new
            {
                total = recordList.Count,
                current_page = currentPage,
                per_page = pageSize,
                last_page = totalPage,/* This is used by the client-side to generate page number buttons 
*/
                next_page_url = nextPageUrl,
                prev_page_url = prevPageUrl,
                records = recordList,
                from = startRecord,
                to = endRecord
            };
            return new JsonResult(finalResult);
        }//end of GetNotesPageByPage() 
         //***************************************** 
         //End of pagination logic code segmet 
         //***************************************** 


        [Authorize("ADMIN")]
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            string customMessage = "";

            var foundOneAccount = Database.CustomerAccounts.SingleOrDefault(x => x.CustomerAccountId == id);

            if (foundOneAccount == null)
            {
                return NotFound(new { message = "Cannot find the customer record! Please refresh the page!" });
            }
            //Call the remove method, pass the foundOneAccount object into it
            //so that the Database object knows what to remove from the database.
            try
            {
                Database.CustomerAccounts.Remove(foundOneAccount);
                //Tell the db model to commit/persist the changes to the database, 
                //I use the following command.
                Database.SaveChanges();
            }
            catch (Exception ex)
            {
                customMessage = "Unable to delete lesson record because " + ex.InnerException.Message + ".";
                return BadRequest(new { message = customMessage });
            }//End of try .. catch block on manage data

            return Ok(new { message = "Deleted customer account successfully" });
        }//end of Delete() Web API method



        [Authorize("ADMIN")]
        [HttpGet("{id}")]
        public IActionResult GetOneRecord(int id)
        {
            //SingleOrDefault returns either null or an object
            var oneCustomer = Database.CustomerAccounts.Include(n=>n.Comments).Include(y=>y.AccountRates).SingleOrDefault(x => x.CustomerAccountId == id);
            List<InstructorAccount> instructors = Database.InstructorAccounts.Where(y => y.CustomerAccountId == id).ToList();
            if (oneCustomer == null)
            {
                return NotFound(new { message = "Unable to retrieve customer data" });
            }
            else
            {
                var response = new
                {
                    customerName = oneCustomer.AccountName,
                    commentsNumber = oneCustomer.Comments.Count,
                    rateRecordNumber = oneCustomer.AccountRates.Count,
                    instructorNumber = instructors.Count
                };
                //end of creation of the anonymous type response object
                return Ok(response);
            }//end of if..else
        }



        [Authorize("ADMIN")]
        [HttpPost]
        public IActionResult Post([FromForm] IFormCollection data)
        {
            int userId = int.Parse(User.FindFirst("userid").Value);
            string customMessage = "";

            //check whether these data from frontEnd can convert to the corresponding datatype
            if (validateDataType(data["rate"], data["start"], data["end"], data["visibility"]) != null)
            {
                return validateDataType(data["rate"], data["start"], data["end"], data["visibility"]);
            }
            
            CustomerAccount newCustomerAccount = new CustomerAccount();

            //Start passing the collected data into the newCustomerAccount
            newCustomerAccount.AccountName = data["accountName"];

            //customer account rate part
            string comments = data["comments"];
            if (comments.Trim(' ') != "") //check whether these comments got content inside, if not, ignore it. System will set null value to it
            {
                //Create new Customer Comment
                CustomerAccountComment newCustomerComment = new CustomerAccountComment();
                newCustomerComment.Comment = data["comments"];
                newCustomerComment.CustomerAccountId = newCustomerAccount.CustomerAccountId;
                newCustomerComment.CreatedById = userId;
                newCustomerComment.UpdatedAt = _appDateTimeService.GetCurrentDateTime();
                newCustomerComment.CreatedById = userId;
                //Pass the comments to customer
                newCustomerAccount.Comments.Add(newCustomerComment);
            }


            //Visibility part
            newCustomerAccount.IsVisible = Convert.ToBoolean(data["visibilityInput"]);


            //Account Rate part
            AccountRate newAccountRate = new AccountRate();
            newAccountRate.CustomerAccountId = newCustomerAccount.CustomerAccountId;
            newAccountRate.RatePerHour = decimal.Parse(data["rate"]);
            newAccountRate.EffectiveStartDate = DateTime.ParseExact(data["start"], "dd/MM/yyyy", CultureInfo.InvariantCulture);
            newAccountRate.EffectiveEndDate = DateTime.ParseExact(data["end"], "dd/MM/yyyy", CultureInfo.InvariantCulture);

            newAccountRate.CreatedById = userId;
            newAccountRate.UpdatedAt = _appDateTimeService.GetCurrentDateTime();
            newAccountRate.CreatedAt = _appDateTimeService.GetCurrentDateTime();
            newAccountRate.UpdatedById = userId;

            //Validate the account rate properties using fluentValidation
            if (validateAccountRateProperty(newAccountRate) != null)
            {
                return validateAccountRateProperty(newAccountRate);
            }
            newCustomerAccount.AccountRates.Add(newAccountRate);


            newCustomerAccount.CreatedById = userId;
            newCustomerAccount.CreatedAt = _appDateTimeService.GetCurrentDateTime();
            newCustomerAccount.UpdatedById = userId;
            newCustomerAccount.UpdatedAt = _appDateTimeService.GetCurrentDateTime();



            //Validate the customer account properties using fluentValidation
            if (validateCustomerAccountProperty(newCustomerAccount) != null)
            {
                return validateCustomerAccountProperty(newCustomerAccount);
            }

            try
            {
                Database.Add(newCustomerAccount);
                //Tell the Database to make the changes permanent (create record)
                Database.SaveChanges();
            }
            catch (Exception ex)
            {
                if (ex.InnerException.Message.Contains("CustomerAccount_AccountName_UniqueConstraint"))
                {
                    return BadRequest(new { message = "Unable to create the CustomerAccount due to duplication of Account Name.", error= "AccountName" });
                }
                else
                {
                    customMessage = "Unable to create Customer Account because " + ex.InnerException.Message + ".";
                    return BadRequest(new { message = customMessage });
                }
            }//End of try .. catch block on saving data
             //Send back an OK with 200 status code

            return Ok(new
            {
                message = "New Customer Account Record has been created successfully."
            });
        }




        [Authorize("ADMIN")]
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromForm] IFormCollection data)
        {
            int userId = int.Parse(User.FindFirst("userid").Value);
            string customMessage = "";

            CustomerAccount foundOneCustomerAccount = Database.CustomerAccounts.SingleOrDefault(x => x.CustomerAccountId == id);

            if (foundOneCustomerAccount == null)
            {
                return NotFound(new { message = "Unable to find the customer information. " });
            }
            else
            {
                //every put request only update one property, either customer account name or visibility 
                if (data["isVisible"] != "0") //It means only change the visibility status
                {
                    foundOneCustomerAccount.IsVisible = foundOneCustomerAccount.IsVisible ? false : true;
                }
                else //It means only change the Name
                {
                    foundOneCustomerAccount.AccountName = data["accountName"];
                }
                foundOneCustomerAccount.UpdatedById = userId;
                foundOneCustomerAccount.UpdatedAt = _appDateTimeService.GetCurrentDateTime();
            }

            //Validate the customer account properties using fluentValidation
            if (validateCustomerAccountProperty(foundOneCustomerAccount) != null)
            {
                return validateCustomerAccountProperty(foundOneCustomerAccount);
            }

            try
            {  //Call the Update method and pass the foundOneStudent object into it
                Database.CustomerAccounts.Update(foundOneCustomerAccount);
                //Tell the ApplicationDbContext object (referenced by the Database property)
                //to make the changes permanent in the database.
                Database.SaveChanges();
            }
            catch (Exception ex)
            {
                if (ex.InnerException.Message.Contains("CustomerAccount_AccountName_UniqueConstraint") == true)
                {
                    return BadRequest(new { message = "Unable to update the Customer Account Name due to duplication." });
                }
                else
                {
                    customMessage = "Unable to update customer account because " + ex.InnerException.Message + ".";
                    return BadRequest(new { message = customMessage });
                }

            }

            //send back the updated info to convenience showing updated info
            return Ok(new
            {
                updatedBy = updatedInfo(id)[0],
                updatedAt = updatedInfo(id)[1]
            });
        }





        //only get updated Info
        public List<string> updatedInfo(int id)
        {
            var oneRecord = Database.CustomerAccounts.Include(x => x.UpdatedBy).SingleOrDefault(x => x.CustomerAccountId == id);

            if (oneRecord == null)
            {
                return null;
            }
            else
            {
                List<string> infoUpdate = new List<string>();
                infoUpdate.Add(oneRecord.UpdatedBy.FullName);
                infoUpdate.Add(Convert.ToDateTime(oneRecord.UpdatedAt).ToString("dd/MM/yyyy"));
                return infoUpdate;
            }
        }


        public IActionResult validateDataType(string ratePerHour, string startDate, string endDate, string visibility)
        {
            string customMessage = "";
            string error = "";
            decimal rateInput;
            bool isVisible;
            DateTime start;
            DateTime end;

            if (!decimal.TryParse(ratePerHour, out rateInput))
            {
                customMessage = "Please enter a number for rate.";
                error = "RatePerHour";
                return BadRequest(new { message = customMessage, errorPlace = error });
            }
            else if (!DateTime.TryParseExact(startDate, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out start))
            {
                customMessage = "Please pick a valid start date from the calender.";
                error = "EffectiveStartDate";
                return BadRequest(new { message = customMessage, errorPlace = error });
            }
            //validating the date type of end date
            else if (!DateTime.TryParseExact(endDate, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out end))
            {
                customMessage = "Please pick a valid end date from the calender.";
                error = "EffectiveEndDate";
                return BadRequest(new { message = customMessage, errorPlace = error });
            }
            else if (!Boolean.TryParse(visibility, out isVisible))
            {
                customMessage = "The slider button has some problems, please refresh the page and retry.";
                return BadRequest(new { message = customMessage});
            }
            else
            {
                return null;
            }
        }

        public IActionResult validateAccountRateProperty(AccountRate obj)
        {
            string error = "";
            string customMessage = "";

            //using fluentValidation to check
            AccountRate_Validation rateSentToValidate = new AccountRate_Validation();
            ValidationResult validationResult = rateSentToValidate.Validate(obj);
            if (!validationResult.IsValid)
            {
                error = validationResult.Errors[0].PropertyName;
                customMessage = validationResult.Errors[0].ErrorMessage;
                return BadRequest(new { message = customMessage, errorPlace = error });
            }
            else
            {
                return null;
            }
        }

        public IActionResult validateCustomerAccountProperty(CustomerAccount obj)
        {
            string error = "";
            string customMessage = "";

            //using fluentValidation to check
            CustomerAccount_Validation accountSentToValidate = new CustomerAccount_Validation();
            ValidationResult validationResult = accountSentToValidate.Validate(obj);
            if (!validationResult.IsValid)
            {
                error = validationResult.Errors[0].PropertyName;
                customMessage = validationResult.Errors[0].ErrorMessage;
                return BadRequest(new { message = customMessage, errorPlace = error });
            }
            else
            {
                return null;
            }
        }
    }


    //Setup a class QueryPagingParametersForCustomerAccount so that we can have cleaner code 
    //to extract values from query sting data passed from the client side     
    public class QueryPagingParametersForCustomerAccount
    {
        [BindRequired]
        public int page_number { get; set; }
        public int per_page { get; set; }
        public string sort_col { get; set; }
        public string sort_order { get; set; }
    }//end of QueryPagingParametersForLessonTypes class 


}
