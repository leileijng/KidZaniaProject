﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.EntityFrameworkCore;
using TMS.Data;
using TMS.Models;
using TMS.Services;
using FluentValidation;
using FluentValidation.Results;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TMS.APIs
{
    [Route("api/[controller]")]
    public class LessonTypesController : Controller
    {

        //The following one member variable and one readonly property are required for every web api controller class. 
        private IAppDateTimeService _appDateTimeService;
        public ApplicationDbContext Database { get; } 
        //Read-only Database property has been declared so that we can reference the given database object



        //The following constructor code pattern is required for every Web API controller class. 

        public LessonTypesController(IAppDateTimeService appDateTimeService,
            ApplicationDbContext database)
        {

            Database = database;
            _appDateTimeService = appDateTimeService;
        } //End of the constructor




        //************************************************************************* 
        // GET api/LessonTypes/GetLessonTypesPageByPage 
        //************************************************************************* 
        [Authorize("ADMIN")]
        [HttpGet("GetLessonTypesPageByPage")]
        public JsonResult GetLessonTypesPageByPage(
                 [FromQuery]QueryPagingParametersForLessonTypes inParameters)
        {
            int pageSize = 10;
            int totalPage = 0;
            int startRecord = 0;
            int endRecord = 0;
            int currentPage = 0; 

            string fieldToSort = inParameters.sort_col; //column name
            string sortDirection = inParameters.sort_order; //"ASC" or "DESC" 

            List<object> recordList = new List<object>();
            int totalRecords = 0;
            if (ModelState.IsValid)
            {
                currentPage = Int32.Parse(inParameters.page_number.ToString());
                pageSize = Int32.Parse(inParameters.per_page.ToString());
            }
            else
            {
                currentPage = 1;
                pageSize = 10;
            }
            if (currentPage == 1)
            {
                startRecord = 1;
            }
            else
            {
                startRecord = (currentPage * pageSize) + 1;
            }
            endRecord = pageSize * currentPage;

            //To use DbCommand class, you need the namespace System.Data.Common 
            //Create a new DbCommand type object 
            DbCommand cmd = Database.Database.GetDbConnection().CreateCommand();
            //Tell the DbCommand object, cmd to open a connection to db  
            cmd.Connection.Open();
            //Pass the SQL to the DbCommand type object, cmd. 
            //Let the DbCommand type object cmd know that this is a stored procedure.    
            cmd.CommandText = "dbo.uspSelectLessonTypes";
            //Tell the DbCommand object, cmd that this is a stored procedure.
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            //Pass the page number value to the stored procedure's @pageNo parameter 
            DbParameter parameter = cmd.CreateParameter();
            parameter.DbType = System.Data.DbType.Int32;
            parameter.ParameterName = "pageNo";
            parameter.Value = currentPage;
            cmd.Parameters.Add(parameter);
            //Pass the page size value to the stored procedure's @pageSize parameter 
            parameter = cmd.CreateParameter();
            parameter.DbType = System.Data.DbType.Int32;
            parameter.ParameterName = "pageSize";
            parameter.Value = pageSize;
            cmd.Parameters.Add(parameter);


            //Pass the field to sort information to the procedures @sortColumn 
            //parameter 
            parameter = cmd.CreateParameter();
            parameter.DbType = System.Data.DbType.String;
            //Hard code this here because not getting it from the client-side 
            parameter.ParameterName = "sortColumn";
            parameter.Value = fieldToSort;//LessonTypeName        
            cmd.Parameters.Add(parameter);


            //Pass the field to sort order to the procedures @sortOrder 
            //parameter 
            parameter = cmd.CreateParameter();
            parameter.DbType = System.Data.DbType.String;
            //Hard code this here because I did not provide code to obtain from clientside         
            parameter.ParameterName = "sortOrder";
            parameter.Value = sortDirection;//ASC      
            cmd.Parameters.Add(parameter);

            //     The above commands will "build-up" one SQL command such as: 
            //     EXEC dbo.uspSelectNotes @userId=1,@pageNo =1,  
            //     @sortColumn='LessonTypeName , @sortOrder='ASC', 
            //     @pageSize = 5 

            DbDataReader dr = cmd.ExecuteReader();//This is the part where SQL is sent to DB    
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    //Get each column values               
                    int recordId = int.Parse(dr["LessonTypeId"].ToString());
                    int rowNumber = int.Parse(dr["ROWNUM"].ToString());
                    string lessonTypeName = dr["LessonTypeName"].ToString();
                    bool isVisible = Convert.ToBoolean(dr["IsVisible"].ToString());
                    string createdBy = dr["CreatedBy"].ToString();
                    string updatedBy = dr["UpdatedBy"].ToString();
                    string createdAt = Convert.ToDateTime(dr["CreatedAt"]).ToString("dd/MM/yyyy");
                    string updatedAt = Convert.ToDateTime(dr["UpdatedAt"]).ToString("dd/MM/yyyy");
                    //totalRecords variable is not included inside the anonymous type
                    //object creation. Instead it will be used outside the loop to 
                    //calculate the "total number of pages" which is needed by the client
                    //side to decide how paging buttons should be created
                    totalRecords = int.Parse(dr["TotalCount"].ToString());
                   
                    //Create an anonymous object and at the same time 
                    //add it into the recordList collection    
                    recordList.Add(new
                    {
                        id = recordId,
                        rowNumber = rowNumber,
                        lessonTypeName = lessonTypeName,
                        isVisible = isVisible,
                        createdBy = createdBy,
                        updatedBy = updatedBy,
                        createdAt = createdAt,
                        updatedAt = updatedAt
                    });
                }
            }
            cmd.Connection.Close();

            totalPage = (int)Math.Ceiling((double)totalRecords / pageSize);

            object finalResult = new object();
            string nextPageUrl = "";
            string prevPageUrl = "";

            if (currentPage == 1)
            {
                prevPageUrl = null;
                nextPageUrl = "/API/LessonTypes/GetLessonTypesPageByPage?per_page=" +
                    pageSize.ToString() + "&page_number=" + (currentPage + 1) + "&sort_col=" + fieldToSort + "&sort_order=" + sortDirection;
            }
            else
            {
                prevPageUrl = "/API/LessonTypes/GetLessonTypesPageByPage?per_page=" +
                    pageSize.ToString() + "&page_number=" + (currentPage - 1) + "&sort_col=" + fieldToSort + "&sort_order=" + sortDirection;
                if (currentPage == totalPage)
                {
                    nextPageUrl = null;
                }
                else
                {
                    nextPageUrl = "/API/LessonTypes/GetLessonTypesPageByPage?per_page=" +
                        pageSize.ToString() + "&page=" + (currentPage + 1) + "&sort_col=" + fieldToSort + "&sort_order=" + sortDirection;
                }
            }
            finalResult = new
            {
                total = recordList.Count,
                current_page = currentPage,
                per_page = pageSize,
                last_page = totalPage,/* This is used by the client-side to generate page number buttons 
*/
                next_page_url = nextPageUrl,
                prev_page_url = prevPageUrl,
                records = recordList,
                from = startRecord,
                to = endRecord
            };
            return new JsonResult(finalResult);
        }//end of GetNotesPageByPage() 
         //***************************************** 
         //End of pagination logic code segmet 
         //***************************************** 


        // GET: api/<controller>



        [Authorize("ADMIN")]
        [HttpGet("{id}")]
        public IActionResult GetOneRecord(int id)
        {
            //SingleOrDefault returns either null or an object
            LessonType foundLessonType = Database.LessonTypes.Include(x => x.CreatedBy).Include(x=>x.UpdatedBy).SingleOrDefault(x => x.LessonTypeId == id);
            if (foundLessonType == null)
            {
                return NotFound(new { message = "Unable to retrieve customer data" });
            }
            else
            {
                var response = new
                {
                    lessonTypeName = foundLessonType.LessonTypeName,
                    createdBy = foundLessonType.CreatedBy.FullName,
                    createdAt = Convert.ToDateTime(foundLessonType.CreatedAt).ToString("dd/MM/yyyy"),
                    updatedBy = foundLessonType.UpdatedBy.FullName,
                    updatedAt = Convert.ToDateTime(foundLessonType.UpdatedAt).ToString("dd/MM/yyyy")
                };
                //end of creation of the anonymous type response object
                return Ok(response);
            }//end of if..else
        }//end of GetOneRecord() Web API method





        [Authorize("ADMIN")]
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            string customMessage = "";

            var foundOneLesson = Database.LessonTypes
            .SingleOrDefault(lesson => lesson.LessonTypeId == id);
            
            if (foundOneLesson == null)
            {
                return NotFound(new { message = "Cannot find the lesson type" });
            }

            //Call the remove method, pass the foundOneLesson object into it
            //so that the Database object knows what to remove from the database.
            try
            {
                Database.LessonTypes.Remove(foundOneLesson);
                //Tell the db model to commit/persist the changes to the database
                Database.SaveChanges();
            }
            catch (Exception ex)
            {
                customMessage = "Unable to delete lesson record because " + ex.InnerException.Message + ".";
                return BadRequest(new { message = customMessage });
            }//End of try .. catch block on manage data

            return Ok(new { message = "Deleted lesson type record successfully!" });
        }//end of Delete() Web API method





        [Authorize("ADMIN")]
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromForm] IFormCollection data)
        {
            int userId = int.Parse(User.FindFirst("userid").Value);
            string customMessage = "";

            LessonType foundOneLesson = Database.LessonTypes.SingleOrDefault(x => x.LessonTypeId == id);
            if (foundOneLesson == null)
            {
                return NotFound(new { message = "Unable to find the lesson information. " });
            }
            else
            {
                //every put request only update one property, either lessontypename or visibility 
                if (data["visibility"] != "0") //It means only change the visibility status
                {
                    foundOneLesson.IsVisible = foundOneLesson.IsVisible ? false : true; //toggle between true and false
                }
                else //It means only change the Name
                {
                    foundOneLesson.LessonTypeName = data["lessonName"];
                }

                //update the updating info
                foundOneLesson.UpdatedById = userId;
                foundOneLesson.UpdatedAt = _appDateTimeService.GetCurrentDateTime();
            }//end of if...else...

            //Validate the lesson type properties using fluentValidation
            if (validateLessonTypeProperty(foundOneLesson) != null)
            {
                return validateLessonTypeProperty(foundOneLesson);
            }

            try
            {  //Call the Update method and pass the foundOneStudent object into it
                Database.LessonTypes.Update(foundOneLesson);
                //Tell the ApplicationDbContext object (referenced by the Database property)
                //to make the changes permanent in the database.
                Database.SaveChanges();
            }
            catch (Exception ex)
            {
                //check for duplication!
                if (ex.InnerException.Message.Contains("LessonType_LessonTypeName_UniqueConstraint") == true)
                {
                    return BadRequest(new { message = "Unable to update the LessonTypeName due to duplication." });
                }
                else
                {
                    customMessage = "Unable to update lesson record because " + ex.InnerException.Message + ".";
                    return BadRequest(new { message = customMessage });
                }

            }//End of try .. catch block on saving data
             //Give a response with status 200. At the same time, attach 
             //a JSON data

            //return ok as well as updating info for updating the table
            return Ok(new
            {
                updatedBy = updatedInfo(id)[0],
                updatedAt = updatedInfo(id)[1]
            });
        }



        


        [Authorize("ADMIN")]
        [HttpPost]
        public IActionResult Post([FromForm] IFormCollection data)
        {
            int userId = int.Parse(User.FindFirst("userid").Value);
            string customMessage = "";
            
            //see whether the visibility can be converted to boolean type
            if (validateDataType(data["visibility"]) != null)
            {
                return validateDataType(data["visibility"]);
            }

            //Create an object lesson type object, newLessonType
            LessonType newLessonType = new LessonType();
            //Start passing the collected data into the newLessonType
            newLessonType.LessonTypeName = data["lessonName"];
            newLessonType.IsVisible = Convert.ToBoolean(data["visibility"]);
            newLessonType.CreatedById = userId;
            newLessonType.CreatedAt = _appDateTimeService.GetCurrentDateTime();
            newLessonType.UpdatedById = userId;
            newLessonType.UpdatedAt = _appDateTimeService.GetCurrentDateTime();

            //Validate the lesson type properties using fluentValidation
            if (validateLessonTypeProperty(newLessonType) != null)
            {
                return validateLessonTypeProperty(newLessonType);
            }

            try
            {
                //Add the newLessonType object into the Database.
                //Equivalent command can be Database.LessonTypes.Add(newLessonType)
                Database.Add(newLessonType);
                //Tell the Database to make the changes permanent (create record)
                Database.SaveChanges();
            }
            catch (Exception ex)
            {
                //check for duplication
                if (ex.InnerException.Message.Contains("LessonType_LessonTypeName_UniqueConstraint") == true)
                {
                    return BadRequest(new { message = "Unable to create new LessonTypeName due to duplication." });
                }
                else
                {
                    customMessage = "Unable to create lesson record because " + ex.InnerException.Message + ".";
                    return BadRequest(new { message = customMessage });
                }
            }//End of try .. catch block on saving data

            return Ok(new
            {
                message = "Saved new Lesson Type Record succesfully."
            });
        }//End of Post web api





        public IActionResult validateLessonTypeProperty(LessonType obj)
        {
            string error = "";
            string customMessage = "";

            //using fluentValidation to check properties
            LessonType_Validation lessonSentToValidate = new LessonType_Validation();
            ValidationResult validationResult = lessonSentToValidate.Validate(obj);
            if (!validationResult.IsValid)
            {
                //everytime show one error only, in case user get confused
                error = validationResult.Errors[0].PropertyName;
                customMessage = validationResult.Errors[0].ErrorMessage;
                return BadRequest(new { message = customMessage, errorPlace = error });
            }
            else
            {
                return null;
            }
        }

        



        public IActionResult validateDataType(string visibility)
        {
            string customMessage = "";
            bool isVisible;

            if (!Boolean.TryParse(visibility, out isVisible))
            {
                customMessage = "The slider button has some problems, please refresh the page and retry.";
                return BadRequest(new { message = customMessage });
            }
            else
            {
                return null;
            }
        }





        public List<string> updatedInfo(int id)
        {
            var oneRecord = Database.LessonTypes.Include(x=>x.UpdatedBy).SingleOrDefault(x => x.LessonTypeId == id);
            if (oneRecord == null)
            {
                return null;
            }
            else
            {
                List<string> infoUpdate = new List<string>();
                infoUpdate.Add(oneRecord.UpdatedBy.FullName);
                infoUpdate.Add(Convert.ToDateTime(oneRecord.UpdatedAt).ToString("dd/MM/yyyy"));//e.g. 01/01/2019
                return infoUpdate;
            }
        }






    }//End of the Web API controller class

    //Setup a class QueryPagingParametersForLessonTypes so that we can have cleaner code to extract values from query sting data passed from the client side     
    public class QueryPagingParametersForLessonTypes
    {
        [BindRequired]
        public int page_number { get; set; }
        public int per_page { get; set; }
        public string sort_col { get; set; }
        public string sort_order { get; set; }
    }//end of QueryPagingParametersForLessonTypes class 

    

}//End of namespace
