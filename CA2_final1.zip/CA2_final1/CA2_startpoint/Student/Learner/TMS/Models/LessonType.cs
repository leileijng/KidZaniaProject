﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using FluentValidation;

namespace TMS.Models
{
    public class LessonType
    {
        public int LessonTypeId { get; set; }
        public string LessonTypeName { get; set; }
        //The instructor view functionality logic will check this property to decide
        //whether to display the lesson type to the user (instructor role user) to choose.
        public bool IsVisible { get; set; }
        public DateTime CreatedAt { get; set; }
        public int CreatedById { get; set; }
        public AppUser CreatedBy { get; set; }
        public DateTime UpdatedAt { get; set; }
        public int UpdatedById { get; set; }
        public AppUser UpdatedBy { get; set; }

    }
    public class LessonType_Validation : AbstractValidator<LessonType>
    {
        public LessonType_Validation()
        {
            //Validate LessonTypeName property
            RuleFor(x => x.LessonTypeName).Must(lessonNameConvention).WithMessage("Please enter valid name with alphanumerical characters or , . _ &'");
            RuleFor(x => x.LessonTypeName).NotEmpty().WithMessage("Lesson Type cannot be empty");
            RuleFor(x => x.LessonTypeName).MaximumLength(100);
            //Validate IsVisible property
            RuleFor(x => x.IsVisible).NotNull().WithMessage("Must set visibility for the lesson type");
        }

        private bool lessonNameConvention(string lessonName)
        {
            if(!Regex.IsMatch(lessonName, "^[a-zA-Z0-9 ,._'&/]*$"))
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}
