﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using FluentValidation;

namespace TMS.Models
{
    public class AccountTimeTable
    {
        public int AccountTimeTableId { get; set; }
        //Note that, 1 is Sunday, 2 is Monday, 3 is Tuesday and 7 is Saturday.
        public int DayOfWeekNumber { get; set; }
        public int AccountRateId { get; set; }
        public AccountRate AccountRate { get; set; }
        public int StartTimeInMinutes { get; set; }
        public int EndTimeInMinutes { get; set; }//http://stackoverflow.com/questions/538739/best-way-to-store-time-hhmm-in-a-database
        //When the instructor needs to create his timesheet for a particular month, the system
        //need to fetch to correct AccountTimeTable entity object which is 
        //applicable (due to AccountTimeTable and AccountRate's effective start and end date) a particular month
        //for the user to "select" to generate the "actual schedule" for that respective month.
        //To create the timesheet data. The server side logic will heavily rely on EffectiveStartDate
        //and EffectiveEndDate
        public DateTime EffectiveStartDate { get; set; }
        public DateTime EffectiveEndDate { get; set; }
        //There may be special situations that the admin need to set an AccountTimeTable record as "not visible" (false)
        //. By setting IsVisible property to false, the record will not be used by the Instructor to see any dates
        //which can be generated from the respective AccountTimeTable record.
        public bool IsVisible { get; set; } 

        public DateTime CreatedAt { get; set; }
        public int CreatedById { get; set; }
        public AppUser CreatedBy { get; set; }
        public DateTime UpdatedAt { get; set; }
        public int UpdatedById { get; set; }
        public AppUser UpdatedBy { get; set; }
    }

    public class AccountTimeTable_Validation : AbstractValidator<AccountTimeTable>
    {
        public AccountTimeTable_Validation()
        {
            RuleFor(x => x.DayOfWeekNumber).NotNull().WithMessage("The day must not be empty");
            RuleFor(x => x.DayOfWeekNumber).InclusiveBetween(1, 7).WithMessage("The day of week is invalid");

            RuleFor(x => x.StartTimeInMinutes).NotNull().WithMessage("The start time must not be empty");
            RuleFor(x => x.StartTimeInMinutes).Must(ConstraintForTime).WithMessage("The wage must be 15 min interval. (i.e. 9.15 A.M, 10.45 A.M.)");
            RuleFor(x => x.StartTimeInMinutes).InclusiveBetween(0, 1440).WithMessage("The start time is invalid");
            RuleFor(x => x.StartTimeInMinutes).LessThan(x => x.EndTimeInMinutes).WithMessage("The start time should be earlier than end time");

            RuleFor(x => x.EndTimeInMinutes).NotNull().WithMessage("The end time must not be empty");
            RuleFor(x => x.EndTimeInMinutes).Must(ConstraintForTime).WithMessage("The wage must be 15 min interval. (i.e. 2.15 P.M, 4.00 P.M.)");
            RuleFor(x => x.EndTimeInMinutes).InclusiveBetween(0, 1440).WithMessage("The end time is invalid");
            RuleFor(x => x.EndTimeInMinutes).GreaterThan(x => x.StartTimeInMinutes).WithMessage("The end time should be later than start time");

            RuleFor(x => x.EffectiveStartDate).NotNull().WithMessage("The start day must not be empty");
            RuleFor(x => x.EffectiveStartDate).GreaterThanOrEqualTo(x => x.AccountRate.EffectiveStartDate).WithMessage("The Timetable Start date must not before the Rate Start date ");
            RuleFor(x => x.EffectiveStartDate).LessThanOrEqualTo(x => x.EffectiveEndDate).WithMessage("The Start date should not be later than End date");

            RuleFor(x => x.EffectiveEndDate).NotNull().WithMessage("The end day must not be empty");
            RuleFor(x => x.EffectiveEndDate).LessThanOrEqualTo(x => x.AccountRate.EffectiveEndDate).WithMessage("The Timetable End date must not after the Rate End date ");
            RuleFor(x => x.EffectiveEndDate).GreaterThanOrEqualTo(x => x.EffectiveStartDate).WithMessage("The End date should not be earlier than Start date");
            
            
        }
        private bool ConstraintForTime(int time)
        {
            if(time % 15 == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
