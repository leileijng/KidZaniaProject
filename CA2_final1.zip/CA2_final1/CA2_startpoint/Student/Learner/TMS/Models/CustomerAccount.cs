﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using FluentValidation;

namespace TMS.Models
{
    public class CustomerAccount
    {
        public CustomerAccount()
        {  //Require a constructor to initialize this List property first.  
            this.AccountRates = new List<AccountRate>();
            this.Comments = new List<CustomerAccountComment>();
        }

        public int CustomerAccountId { get; set; }
        public string AccountName { get; set; }
        public List<CustomerAccountComment> Comments { get; set; }
        public bool IsVisible { get; set; }
        public DateTime CreatedAt { get; set; }
        public int CreatedById { get; set; }
        public AppUser CreatedBy { get; set; }
        public DateTime UpdatedAt { get; set; }
        public int UpdatedById { get; set; }
        public AppUser UpdatedBy { get; set; }

        public List<InstructorAccount> InstructorAccounts { get; set; }
        public List<AccountRate> AccountRates { get; set; }
    }

    public class CustomerAccount_Validation : AbstractValidator<CustomerAccount>
    {
        public CustomerAccount_Validation()
        {
            //validate AccountName property
            RuleFor(x => x.AccountName).NotEmpty().WithMessage("Account Name cannot be empty!"); 
            RuleFor(x => x.AccountName).Must(customerNameConvention).WithMessage("Please enter valid name with alphanumerical characters or , . _ - '");
            RuleFor(x => x.AccountName).MaximumLength(100);

            //validate AccountRates property
            RuleFor(x => x.AccountRates).NotNull().WithMessage("Every customer account must have at least one account rate");

            //validate IsVisible property
            RuleFor(x => x.IsVisible).NotNull().WithMessage("Must set visibility for the lesson type");
        }

        private bool customerNameConvention(string accountName)
        {
            if (!Regex.IsMatch(accountName, "^[a-zA-Z0-9 ,._'&/]*$"))
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}
