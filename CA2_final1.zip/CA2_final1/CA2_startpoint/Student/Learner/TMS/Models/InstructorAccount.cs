﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FluentValidation;

namespace TMS.Models
{
    public class InstructorAccount
    {
        public int InstructorAccountId { get; set; }
        public int InstructorId { get; set; }
        public AppUser Instructor { get; set; }
        public int CustomerAccountId { get; set; }
        public CustomerAccount CustomerAccount { get; set; }

        public decimal WageRate { get; set; }

        /* Note: The customer shared that very often instructor will argue with office admin  on issues      
        such as "I cannot see my account to create my timesheet. You did not assign me to the account." 
        The intention for having CreatedAt, CreatedBy and CreatedById is to capture such data inside the 
        system database to assist in dispute investigation*/
        public DateTime CreatedAt { get; set; }
        public int CreatedById { get; set; }
        public AppUser CreatedBy { get; set; }

    }
    public class InstructorAccount_Validation : AbstractValidator<InstructorAccount>
    {
        public InstructorAccount_Validation()
        {
            RuleFor(x => x.WageRate).NotEmpty().WithMessage("The wage input must not be empty");
            RuleFor(x => x.WageRate).Must(ConstraintForWage).WithMessage("The wage must be from 50 to 80, with step of 5. (i.e. 50, 55, 65)");
        }
        private bool ConstraintForWage(decimal wage)
        {
            decimal[] possibleWages = { 50, 55, 60, 65, 70, 75, 80 };
            if (possibleWages.Contains(wage))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
    
}
