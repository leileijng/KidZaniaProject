﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FluentValidation;

namespace TMS.Models
{
    public class AccountRate
    {
        public int AccountRateId { get; set; }
        public int CustomerAccountId { get; set; }
        public CustomerAccount CustomerAccount { get; set; }
        public decimal RatePerHour { get; set; }
        public DateTime EffectiveStartDate { get; set; }
        public DateTime EffectiveEndDate { get; set; }
        public DateTime CreatedAt { get; set; }
        public int CreatedById { get; set; }
        public AppUser CreatedBy { get; set; }
        public DateTime UpdatedAt { get; set; }
        public int UpdatedById { get; set; }
        public AppUser UpdatedBy { get; set; }
        public List<AccountTimeTable> AccountTimeTables{ get; set; }
    }

    public class AccountRate_Validation : AbstractValidator<AccountRate>
    {
        public AccountRate_Validation()
        {
            RuleFor(x => x.RatePerHour).NotEmpty().WithMessage("The rate input must not be empty");
            RuleFor(x => x.RatePerHour).ExclusiveBetween(0, 10000).WithMessage("The rate range should be between 0 and 10000 (exclusive).");
            RuleFor(x => x.RatePerHour).ScalePrecision(2, 6).WithMessage("Rate decimal place is restricted to 2 only.");
            RuleFor(x => x.EffectiveEndDate).GreaterThanOrEqualTo(x => x.EffectiveStartDate).WithMessage("The End date should be latter than Start date");
            
        }
    }
}
