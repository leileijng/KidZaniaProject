https://ui.toast.com/tui-calendar
Obtained this to display the schedule