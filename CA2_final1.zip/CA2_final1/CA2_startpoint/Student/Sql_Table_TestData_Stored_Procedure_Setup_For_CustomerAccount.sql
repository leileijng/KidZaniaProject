use TMSDB_1844638
IF OBJECT_ID('dbo.uspSelectCustomerAccount', 'P') IS NOT NULL
DROP PROCEDURE dbo.uspSelectCustomerAccount;
Go

CREATE PROCEDURE uspSelectCustomerAccount
(
    /* Optional Filters for Dynamic Search*/
	/* The following one parameter is optional and the practical example do not use them*/
	/* It the parameters still remain here to assist those learners who 
	     wish to try out search feature (search by partial note text etc.) for user to use*/
  @accountName NVARCHAR(200) = NULL,
  @createdBy NVARCHAR(100) = NULL,
  @updatedBy NVARCHAR(100) = NULL,

  /*The following four parameter variables are often fixed for any stored procedure 
      which supports record paging */
  /*� Pagination Parameters */
  /*-- If no argument is provided for @pageNo (e.g. @pageNo=1 is missing), the default value is 1 */
  @pageNo INT = 1,   
  @pageSize INT = 10,
   /*� Sorting Parameters */
   /*-- If no argument is provided for @sortColumn parameter
          For example, @sortColumn='DONEAT' is missing, the default value is 'DEADLINE' */
   @sortColumn NVARCHAR(20) = 'AccountName',
   @sortOrder NVARCHAR(4)='ASC'
)
AS
BEGIN
    /*�Declaring local Variables corresponding to parameters for modification */
    DECLARE 
    @_customerAccountName NVARCHAR(100),
	@_createdBy NVARCHAR(100),  
	@_updatedBy NVARCHAR(100),
    /*�The following 6 local variables are used as part of the SQL logic to support
	      fetching the correct records fitting into the specified page number.
		  These variables are fixed for all stored procedures which support record paging. */
    @_pageNbr INT,
    @_pageSize INT,
    @_sortCol NVARCHAR(20),
    @_firstRec INT,
    @_lastRec INT,
    @_totalRows INT

    /*Setting local Variables*/
	/*Copying all parameter input values into the respective local variables */
    SET @_customerAccountName = LTRIM(RTRIM(@accountName))
	SET @_createdBy = LTRIM(RTRIM(@createdBy))
	SET @_updatedBy = LTRIM(RTRIM(@updatedBy))
	/*The following 6 commands rarely changed unless I encounter new inspiration
	   shared by good developers' articles and video */
	/*These 6 commands are used to calculate the correct set of records that can fit
	    into the specified page number (e.g. page 1, page 2 etc). 
		Without the correct value for the @_firstRec and @lastRec, the SQL logic will fail to retrieve
		the correct set of records */
    SET @_pageNbr = @pageNo
    SET @_pageSize = @pageSize
    SET @_sortCol = LTRIM(RTRIM(@sortColumn))

    SET @_firstRec = ( @_pageNbr - 1 ) * @_pageSize
    SET @_lastRec = ( @_pageNbr * @_pageSize + 1 )
    SET @_totalRows = @_firstRec - @_lastRec + 1

    ; WITH CTE_Results
    AS (
    SELECT ROW_NUMBER() OVER (ORDER BY

	/* These are just partial code to decide sort by which column and sequence */
	/* Notice I did not provide all. For example, I have skipped coding sort logic for AppNotePriorityLevelId */
        CASE WHEN (@_sortCol = 'ACCOUNTNAME' AND @sortOrder='ASC')
                    THEN ACCOUNTNAME
        END ASC,
        CASE WHEN (@_sortCol = 'ACCOUNTNAME' AND @sortOrder='DESC')
                  THEN ACCOUNTNAME
        END DESC,

        CASE WHEN (@_sortCol = 'ISVISIBLE' AND @sortOrder='ASC')
                  THEN IsVisible
        END ASC,
        CASE WHEN @_sortCol = 'ISVISIBLE' AND @sortOrder='DESC'
                THEN IsVisible
        END DESC


  ) AS ROWNUM,
  Count(*) over () AS TotalCount,
  ca.CustomerAccountId,
  ca.AccountName,
  ca.IsVisible,
  ca.UpdatedAt,
  ca.CreatedAt,
  au1.FullName AS CreatedBy, 
  au2.FullName As UpdatedBy
 FROM customerAccount ca 
 JOIN AppUser au1 
ON ca.CreatedById = au1.Id
 join AppUser au2
On ca.UpdatedById = au2.Id
 WHERE
    (@_customerAccountName IS NULL OR AccountName LIKE '%' + @_customerAccountName + '%'))

SELECT
  TotalCount,
  ROWNUM,
  CustomerAccountId,
  AccountName,
  IsVisible,
  UpdatedAt,
  CreatedAt,
  CreatedBy,
  UpdatedBy
FROM CTE_Results AS CPC
WHERE
        ROWNUM > @_firstRec
         AND ROWNUM < @_lastRec
 ORDER BY ROWNUM ASC

END
GO
/*********************************************************************/
-- END
-- The code which is required to create AppNote, AppNotePriorityLevel table, test records
-- and one stored procedure which supports record paging functionality
/*********************************************************************/
