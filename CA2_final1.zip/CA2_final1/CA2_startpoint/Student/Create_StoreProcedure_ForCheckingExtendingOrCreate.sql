
CREATE PROCEDURE uspCheckForExtendDateOrCreateNewRateRecord  @customerId int,@StartDate date, @EndDate date, @AccountRate decimal
AS(
SELECT * FROM AccountRate WHERE 
    (DateAdd(DAY, -1, EffectiveStartDate) = @EndDate) or (DateAdd(DAY, 1, EffectiveEndDate) = @StartDate) AND AccountRate.RatePerHour = @AccountRate And
	AccountRate.CustomerAccountId = @customerId 
)



